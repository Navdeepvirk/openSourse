Android 開源項目分類匯總，最新最全版可見 [codekk.com](https://p.codekk.com/)
====================
Other: [English Version](https://github.com/Trinea/android-open-project/tree/master/English%20Version), [繁體版](https://github.com/Trinea/android-open-project/tree/master/%E7%B9%81%E9%AB%94%E4%B8%AD%E6%96%87%E7%89%88), [Website Version](https://p.codekk.com/).    

### 一、codekk.com 
<a href="https://codekk.com" target="_blank">codekk.com</a> 收集了數萬開源項目。支持最新開源項目查看和自動推送、支持開源項目搜索，歡迎瀏覽 :)  


### 二、開發助手 App
開發助手是個強大的開發工具，由 Trinea 從 2017 年初正式對外發佈。它能夠用來反編譯其他應用、查看其他應用佈局和控件信息、屏幕取色(顏色取樣器)、查看 Activity 歴史記錄、查看其他應用 Manifest、查看最近使用和最近安裝的應用、提取任何應用 Apk 和 So 文件、查看最新開源項目、調試應用、查看手機軟硬件信息等，更多功能持續添加中。  
  
可從各大手機應用市場搜素`開發助手`下載，包括 **小米應用商店**、**華為應用商店**、**Vivo 應用市場**、**Opp 應用市場**、**[Google Play](https://play.google.com/store/apps/details?id=cn.trinea.android.developertools)**、[酷安](https://coolapk.com/apk/cn.trinea.android.developertools)**、[應用寶](http://android.myapp.com/myapp/detail.htm?apkName=cn.trinea.android.developertools)**    
![](https://lh3.googleusercontent.com/ERb20Y50r3u_tZMMlqpH5cnS_MC_n366WoKvEjJyFfHz6d-EwvhaEUf7ZKAgRajboTWR=w720-h440-rw)   

### 三、微信公眾號 codekk
專註於技術分享、職業成長、互聯網內推、開發助手版本更新，二維碼如下：  
![img](https://www.trinea.cn/wp-content/uploads/2016/01/weixin-codekk-160.jpg)  


### 四、關於我，歡迎關註
GitHub: <a href="https://github.com/Trinea">Trinea</a>  &nbsp;&nbsp;&nbsp;&nbsp;微博：<a title="Android 技術及移動互聯網分享" href="http://weibo.com/trinea?s=6cm7D0" target="_blank">Trinea</a>&nbsp;&nbsp;&nbsp;&nbsp;個人主頁：<a title="關註於 Android、Java、性能優化、開源項目" href="https://www.trinea.cn/" target="_blank">trinea.cn</a>  


給朋友分享本站：<a href="http://service.weibo.com/share/share.php?url=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&title=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86250%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8cB%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&appkey=1657413438&searchPic=true" target="_blank" title="分享到新浪微博" style="width:100%"><img src="http://farm8.staticflickr.com/7342/13103239365_e5cd37fbac_o.png" title="分享到新浪微博"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&title=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86250%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&desc=&summary=&site=www.trinea.cn" target="_blank" title="分享到 QQ 空間" style="width:100%"><img src="http://farm8.staticflickr.com/7418/13103935825_209bd521f0_o.jpg"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://twitter.com/intent/tweet?text=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86250%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40trinea_cn+https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&pic=" target="_blank" title="Share on twitter" style="width:100%"><img src="http://farm4.staticflickr.com/3764/13104038813_03933d4394_o.png"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&t=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86250%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&pic" target="_blank" title="Share on facebook" style="width:100%"><img src="http://farm4.staticflickr.com/3801/13104038583_b03d5cafac_o.png"/></a>  

## 目前包括(內容比較陳舊，最新最全及不斷更新版本請見 <a href="https://codekk.com" target="_blank">codekk.com</a>)：
>[Android開源項目第一篇——個性化控件(View)篇](https://github.com/Trinea/android-open-project#%E7%AC%AC%E4%B8%80%E9%83%A8%E5%88%86-%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6view)  
*&nbsp;&nbsp;包括[ListView](https://github.com/Trinea/android-open-project#%E4%B8%80listview)、[ActionBar](https://github.com/Trinea/android-open-project#%E4%BA%8Cactionbar)、[Menu](https://github.com/Trinea/android-open-project#%E4%B8%89menu)、[ViewPager](https://github.com/Trinea/android-open-project#%E5%9B%9Bviewpager-gallery)、[Gallery](https://github.com/Trinea/android-open-project#%E5%9B%9Bviewpager-gallery)、[GridView](https://github.com/Trinea/android-open-project#%E4%BA%94gridview)、[ImageView](https://github.com/Trinea/android-open-project#%E5%85%ADimageview)、[ProgressBar](https://github.com/Trinea/android-open-project#%E4%B8%83progressbar)、[TextView](https://github.com/Trinea/android-open-project#%E5%85%ABtextview)、[ScrollView](https://github.com/Trinea/android-open-project#%E4%B9%9Dscrollview)、[TimeView](https://github.com/Trinea/android-open-project#%E5%8D%81timeview)、[TipView](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%B8%80tipview)、[FlipView](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%BA%8Cflipview)、[ColorPickView](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%B8%89colorpickview)、[GraphView](https://github.com/Trinea/android-open-project#%E5%8D%81%E5%9B%9Bgraphview)、[UI Style](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%BA%94ui-style)、[其他](https://github.com/Trinea/android-open-project#%E5%8D%81%E5%85%AD%E5%85%B6%E4%BB%96)*  
[Android開源項目第二篇——工具庫篇](https://github.com/Trinea/android-open-project#%E7%AC%AC%E4%BA%8C%E9%83%A8%E5%88%86-%E5%B7%A5%E5%85%B7%E5%BA%93)  
*&nbsp;&nbsp;包括[依賴注入](https://github.com/Trinea/android-open-project#%E4%B8%80%E4%BE%9D%E8%B5%96%E6%B3%A8%E5%85%A5di)、[圖片緩存](https://github.com/Trinea/android-open-project#%E4%BA%8C%E5%9B%BE%E7%89%87%E7%BC%93%E5%AD%98)、[網絡相關](https://github.com/Trinea/android-open-project#%E4%B8%89%E7%BD%91%E7%BB%9C%E7%9B%B8%E5%85%B3)、[數據庫ORM工具包](https://github.com/Trinea/android-open-project#%E5%9B%9B%E6%95%B0%E6%8D%AE%E5%BA%93-orm%E5%B7%A5%E5%85%B7%E5%8C%85)、[Android公共庫](https://github.com/Trinea/android-open-project#%E4%BA%94android%E5%85%AC%E5%85%B1%E5%BA%93)、[高版本向低版本兼容庫](https://github.com/Trinea/android-open-project#%E5%85%ADandroid-%E9%AB%98%E7%89%88%E6%9C%AC%E5%90%91%E4%BD%8E%E7%89%88%E6%9C%AC%E5%85%BC%E5%AE%B9)、[多媒體](https://github.com/Trinea/android-open-project#%E4%B8%83%E5%A4%9A%E5%AA%92%E4%BD%93%E7%9B%B8%E5%85%B3)、[事件總線](https://github.com/Trinea/android-open-project#%E5%85%AB%E4%BA%8B%E4%BB%B6%E6%80%BB%E7%BA%BF%E8%AE%A2%E9%98%85%E8%80%85%E6%A8%A1%E5%BC%8F)、[傳感器](https://github.com/Trinea/android-open-project#%E4%B9%9D%E4%BC%A0%E6%84%9F%E5%99%A8)、[安全](https://github.com/Trinea/android-open-project#%E5%8D%81%E5%AE%89%E5%85%A8)、[插件化](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%B8%80%E6%8F%92%E4%BB%B6%E5%8C%96)、[文件](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%BA%8C%E6%96%87%E4%BB%B6)、[其他](https://github.com/Trinea/android-open-project#%E5%8D%81%E4%B8%89%E5%85%B6%E4%BB%96)*  
[Android開源項目第三篇——優秀項目篇](https://github.com/Trinea/android-open-project#%E7%AC%AC%E4%B8%89%E9%83%A8%E5%88%86-%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE)  
*&nbsp;&nbsp;比較有意思的完整的Android項目*  
[Android開源項目第四篇——開發及測試工具篇](https://github.com/Trinea/android-open-project#%E7%AC%AC%E5%9B%9B%E9%83%A8%E5%88%86-%E5%BC%80%E5%8F%91%E5%B7%A5%E5%85%B7%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7)  
*&nbsp;&nbsp;包括[開發效率工具](https://github.com/Trinea/android-open-project#%E4%B8%80%E5%BC%80%E5%8F%91%E6%95%88%E7%8E%87%E5%B7%A5%E5%85%B7)、[開發自測相關](https://github.com/Trinea/android-open-project#%E4%BA%8C%E5%BC%80%E5%8F%91%E8%87%AA%E6%B5%8B%E7%9B%B8%E5%85%B3)、[測試工具](https://github.com/Trinea/android-open-project#%E4%B8%89%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7)、[開發及編譯環境](https://github.com/Trinea/android-open-project#%E5%9B%9B%E5%BC%80%E5%8F%91%E5%8F%8A%E7%BC%96%E8%AF%91%E7%8E%AF%E5%A2%83)、[其他](https://github.com/Trinea/android-open-project#%E4%BA%94%E5%85%B6%E4%BB%96)*  
[Android開源項目第五篇——優秀個人和團體篇](https://github.com/Trinea/android-open-project#%E7%AC%AC%E4%BA%94%E9%83%A8%E5%88%86)  
*&nbsp;&nbsp;樂于分享並且有一些很不錯的開源項目的[個人](https://github.com/Trinea/android-open-project#%E4%B8%80%E4%B8%AA%E4%BA%BA)和[組織](https://github.com/Trinea/android-open-project#%E4%BA%8C%E7%BB%84%E7%BB%87)，包括JakeWharton、Chris Banes、Koushik Dutta等大牛*  

## 第一部分 個性化控件(View)  
主要介紹那些不錯個性化的View，包括ListView、ActionBar、Menu、ViewPager、Gallery、GridView、ImageView、ProgressBar、TextView、ScrollView、TimeView、TipView、FlipView、ColorPickView、GraphView、UI Style等等。  
、其他
#### 一、ListView  
1. android-pulltorefresh  
一個強大的拉動刷新開源項目，支持各種控件下拉刷新，ListView、ViewPager、WevView、ExpandableListView、GridView、ScrollView、Horizontal  ScrollView、Fragment上下左右拉動刷新，比下面johannilsson那個只支持ListView的強大的多。並且他實現的下拉刷新ListView在item不足一屏情況下也不會顯示刷新提示，體驗更好。  
項目地址：https://github.com/chrisbanes/Android-PullToRefresh  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/pull-to-refreshview-demo.apk?raw=true  
APP示例：新浪微博各個頁面  
   
1. android-pulltorefresh-listview  
下拉刷新ListView  
項目地址：https://github.com/johannilsson/android-pulltorefresh  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/pull-to-refresh-listview-demo.apk?raw=true  
PS：這個被很多人使用的項目實際有不少bug，推薦使用上面的android-pulltorefresh  

1. android-Ultra-Pull-to-Refresh    
這是現在已經停止維護的下拉刷新項目的替代方案，繼承于ViewGroup, 可以包含任何View，功能比SwipeRefreshLayout強大，稱為終極下拉刷新。
使用起來非常簡單，良好的設計，如果你想定製自己的UI樣式，那也非常簡單，就像給ListView加一個Header View那麼簡單。
支持 `API LEVEL >= 8`  
項目地址：https://github.com/liaohuqiu/android-Ultra-Pull-To-Refresh   
Demo地址：https://github.com/liaohuqiu/android-Ultra-Pull-To-Refresh/blob/master/ptr-demo/target/ultra-ptr-demo.apk?raw=true  
效果圖：   
<div>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/contains-all-of-views.gif' width="150px"/>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/release-to-refresh.gif' width="150px"/>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/auto-refresh.gif' width="150px"/>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/store-house-string-array.gif' width="150px"/>  
</div>   
   
1. DropDownListView  
下拉刷新及滑動到底部加載更多ListView  
項目地址：https://github.com/Trinea/AndroidCommon  
Demo地址：https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
文檔介紹：https://www.trinea.cn/android/dropdown-to-refresh-and-bottom-load-more-listview/  
   
1. DragSortListView  
拖動排序的ListView，同時支持ListView滑動item刪除，各個Item高度不一、單選、複選、CursorAdapter做爲適配器、拖動背景變化等  
項目地址：https://github.com/bauerca/drag-sort-listview  
Demo地址：https://play.google.com/store/apps/details?id=com.mobeta.android.demodslv  
APP示例：Wordpress Android  
   
1. SwipeListView  
支持定義ListView左右滑動事件，支持左右滑動位移，支持定義動畫時間  
項目地址：https://github.com/47deg/android-swipelistview  
Demo地址：https://play.google.com/store/apps/details?id=com.fortysevendeg.android.swipelistview  
APP示例：微信  
   
1. SwipeListView  
持ListView的Item的拖動排序、左右滑動事件，可自定義左右滑動顯示文字、圖標、位移，同時支持onItemClick、onItemLongClick等監聽器，提供豐富的回調接口。  
項目地址：https://github.com/yydcdut/SlideAndDragListView  
Demo地址：https://github.com/yydcdut/SlideAndDragListView/blob/master/apk/sdlv.apk?raw=true  
APP示例：Android 手机QQ 5.0  
效果圖：![Renderings](https://raw.githubusercontent.com/yydcdut/SlideAndDragListView/master/gif/v1.1.gif) 
   
1. RecyclerViewSwipeDismiss  
輕量級支持support-v7中的RecyclerView的滑動刪除(Swipe to dismiss)行為，不需要修改源代碼，只要間單的邦定`onTouchListener`   
項目地址：https://github.com/CodeFalling/RecyclerViewSwipeDismiss    
效果圖：![Renderings](http://i2.tietuku.com/a5a1a6fbd300397a.gif) 
   
1. Android-SwipeToDismiss  
滑動Item消失ListView  
項目地址：https://github.com/romannurik/Android-SwipeToDismiss  
支持3.0以下版本見：https://github.com/JakeWharton/SwipeToDismissNOA  
Demo地址：https://github.com/JakeWharton/SwipeToDismissNOA/SwipeToDismissNOA.apk/qr_code  
   
1. StickyListHeaders  
GroupName滑動到頂端時會固定不動直到另外一個GroupName到達頂端的ExpandListView，支持快速滑動，支持Android2.3及以上  
項目地址：https://github.com/emilsjolander/StickyListHeaders  
APP示例：Android 4.0聯系人  
效果圖：![Renderings](https://raw.github.com/emilsjolander/StickyListHeaders/master/demo.gif)  
   
1. pinned-section-listview  
GroupName滑動到頂端時會固定不動直到另外一個GroupName到達頂端的ExpandListView  
項目地址：https://github.com/beworker/pinned-section-listview  
效果圖：![Renderings](https://raw.github.com/beworker/pinned-section-listview/master/screen1.png)  
   
1. PinnedHeaderListView  
GroupName滑動到頂端時會固定不動直到另外一個GroupName到達頂端的ExpandListView  
項目地址：https://github.com/JimiSmith/PinnedHeaderListView  
   
1. QuickReturnHeader  
ListView/ScrollView的header或footer，當向下滾動時消失，向上滾動時出現  
項目地址：https://github.com/ManuelPeinado/QuickReturnHeader  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/quick-return-header-demo.apk?raw=true  
APP示例：google plus  
   
1. IndexableListView  
ListView右側會顯示item首字母快捷索引，點擊可快速滑動到某個item  
項目地址：https://github.com/woozzu/IndexableListView  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/indexable-listview.apk?raw=true  
APP示例：微信通訊錄、小米聯系人  
   
1. CustomFastScrollView  
ListView快速滑動，同時屏幕中間PopupWindows顯示滑動到的item內容或首字母  
項目地址：https://github.com/nolanlawson/CustomFastScrollViewDemo  
效果圖：![Renderings](https://raw.github.com/nolanlawson/CustomFastScrollViewDemo/master/example.png)  
   
1. Android-ScrollBarPanel  
ListView滑動時固定的Panel指示顯示在scrollbar旁邊  
項目地址：https://github.com/rno/Android-ScrollBarPanel  
效果展示：https://github.com/rno/Android-ScrollBarPanel/raw/master/demo_capture.png  
   
1. SlideExpandableListView  
用戶點擊listView item滑出固定區域，其他item的區域收縮  
項目地址：https://github.com/tjerkw/Android-SlideExpandableListView  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/slide-expandable-listView-demo.apk?raw=true  
   
1. JazzyListView  
ListView及GridView item以特殊動畫效果進入屏幕，效果包括grow、cards、curl、wave、flip、fly等等  
項目地址：https://github.com/twotoasters/JazzyListView  
Demo地址：https://play.google.com/store/apps/details?id=com.twotoasters.jazzylistview.sample  
效果展示：http://lab.hakim.se/scroll-effects/  
   
1. ListViewAnimations  
帶Item顯示動畫的ListView，動畫包括底部飛入、其他方向斜飛入、下層飛入、漸變消失、滑動刪除等  
項目地址：https://github.com/nhaarman/ListViewAnimations  
Demo地址：https://play.google.com/store/apps/details?id=com.haarman.listviewanimations  
APP示例：Google plus、Google Now卡片式進入、小米系統中應用商店、聯系人、遊戲中心、音樂、文件管理器的ListView、Ultimate、Light Flow Lite、TreinVerkeer、Running Coach、Pearl Jam Lyrics、Calorie Chart、Car Hire、Super BART、DK FlashCards、Counter Plus、Voorlees Verhaaltjes 2.0  
   
1. DevsmartLib-Android  
橫向ListView  
項目地址：https://github.com/dinocore1/DevsmartLib-Android  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/horizontal-listview-demo.apk?raw=true  
   
1. HorizontalVariableListView  
支持Item寬度不一致的ListView  
項目地址：https://github.com/sephiroth74/HorizontalVariableListView   
   
1. LinearListView  
用LinearLayout實現的ListView，可解決多個ListView並且等問題。目前自己也有需要，等親自嘗試過後會再具體介紹  
項目地址：https://github.com/frankiesardo/LinearListView   
  
1. MultiChoiceAdapter  
支持多選的ListView Adapter  
項目地址：https://github.com/ManuelPeinado/MultiChoiceAdapter   
Demo地址：https://play.google.com/store/apps/details?id=com.manuelpeinado.multichoiceadapter.demo  

1. EnhancedListView  
支持橫向滑動滑動刪除列表項以及撤銷刪除的ListView，該項目的前身是[SwipeToDismissUndoList](https://github.com/timroes/SwipeToDismissUndoList)   
項目地址：https://github.com/timroes/EnhancedListView   
Demo地址：https://play.google.com/store/apps/details?id=de.timroes.android.listviewdemo&rdid=de.timroes.android.listviewdemo   
   
1. ListBuddies  
自動滾動的雙列ListView ，兩個ListView滾動速度不一致，有視差效果   
項目地址：https://github.com/jpardogo/ListBuddies   
Demo地址：https://play.google.com/store/apps/details?id=com.jpardogo.android.listbuddies   
效果展示：![Renderings](https://raw.github.com/jpardogo/ListBuddies/master/art/screenshot_listbuddies_2.png)  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>     

#### 二、ActionBar  
1. ActionBarSherlock  
爲Android所有版本提供統一的ActionBar，解決4.0以下ActionBar的適配問題  
項目地址：https://github.com/JakeWharton/ActionBarSherlock  
Demo地址：https://play.google.com/store/apps/details?id=com.actionbarsherlock.sample.demos  
APP示例：太多了。。現在連google都在用  
   
1. ActionBar-PullToRefresh  
下拉刷新，ActionBar出現加載中提示  
項目地址：https://github.com/chrisbanes/ActionBar-PullToRefresh  
Demo地址：https://play.google.com/store/apps/details?id=uk.co.senab.actionbarpulltorefresh.samples.stock  
APP示例：Gmail，Google plus，知乎等  
   
1. FadingActionBar  
ListView向下滾動逐漸顯現的ActionBar  
項目地址：https://github.com/ManuelPeinado/FadingActionBar  
Demo地址：https://play.google.com/store/apps/details?id=com.manuelpeinado.fadingactionbar.demo  
APP示例：google music，知乎  
   
1. NotBoringActionBar  
google music下拉收縮的ActionBar  
項目地址：https://github.com/flavienlaurent/NotBoringActionBar  
Demo地址：http://flavienlaurent.com/blog/2013/11/20/making-your-action-bar-not-boring/  
APP示例：Google音樂  
   
1. RefreshActionItem  
帶進度顯示和刷新按鈕的ActionBar  
項目地址：https://github.com/ManuelPeinado/RefreshActionItem  
Demo地址：https://play.google.com/store/apps/details?id=com.manuelpeinado.refreshactionitem.demo  
APP示例：The New York Times，DevAppsDirect.  
   
1. GlassActionBar  
類似玻璃的有一定透明度的ActionBar  
項目地址：https://github.com/ManuelPeinado/GlassActionBar  
Demo地址：https://play.google.com/store/apps/details?id=com.manuelpeinado.glassactionbardemo  
APP示例：google music  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 三、Menu   
1. MenuDrawer   
滑出式菜單，通過拖動屏幕邊緣滑出菜單，支持屏幕上下左右劃出，支持當前View處于上下層，支持Windows邊緣、ListView邊緣、ViewPager變化劃出菜單等。  
項目地址：https://github.com/SimonVT/android-menudrawer  
Demo地址：http://simonvt.github.io/android-menudrawer/  
APP示例：Gmail、Google Music等大部分google app  
   
1. SlidingMenu  
滑出式菜單，通過拖動屏幕邊緣滑出菜單，支持屏幕左右劃出，支持菜單zoom、scale、slide up三種動畫樣式出現。  
項目地址：https://github.com/jfeinstein10/SlidingMenu  
Demo地址：https://play.google.com/store/apps/details?id=com.slidingmenu.example  
APP示例：Foursquare, LinkedIn, Zappos, Rdio, Evernote Food, Plume, VLC for Android, ESPN ScoreCenter, MLS MatchDay, 9GAG, Wunderlist 2, The Verge, MTG Familiar, Mantano Reader, Falcon Pro (BETA), MW3 Barracks  
MenuDrawer和SlidingMenu比較：SlidingMenu支持菜單動畫樣式出現，MenuDrawer支持菜單view處于內容的上下層  
   
1. ArcMenu  
支持類似Path的左下角動畫旋轉菜單及橫向劃出菜單、圓心彈出菜單  
項目地址：https://github.com/daCapricorn/ArcMenu  
APP示例：Path  
效果圖：![Renderings](https://dl.dropboxusercontent.com/u/11369687/preview0.png)  
https://dl.dropboxusercontent.com/u/11369687/preview1.png  
https://dl.dropboxusercontent.com/u/11369687/raymenu.png  
   
1. android-satellite-menu  
類似Path的左下角動畫旋轉菜單  
項目地址：https://github.com/siyamed/android-satellite-menu  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/satellite-menu-demo.apk?raw=true  
APP示例：Path  
   
1. radial-menu-widget  
圓形菜單，支持二級菜單  
項目地址：https://code.google.com/p/radial-menu-widget/  
效果圖：http://farm8.staticflickr.com/7377/11621125154_d1773c2dcc_o.jpg  
   
1. Android Wheel Menu  
圓形旋轉選取菜單  
項目地址：https://github.com/anupcowkur/Android-Wheel-Menu  
效果圖：![Renderings](https://raw.github.com/anupcowkur/Android-Wheel-Menu/master/graphics/wheel.gif)  
   
1. FoldingNavigationDrawer  
滑動並以折疊方式打開菜單  
項目地址：https://github.com/tibi1712/FoldingNavigationDrawer-Android  
使用介紹：https://play.google.com/store/apps/details?id=com.ptr.folding.sample  
效果圖：![Renderings](https://lh6.ggpht.com/VnKUZenAozQ0KFAm5blFTGqMaKFjvX-BK2JH-jrX1sIXVTqciACqRhqFH48hc4pm2Q=h310-rw)  

1. AndroidResideMenu  
仿 Dribbble 的邊欄菜單   
項目地址：https://github.com/SpecialCyCi/AndroidResideMenu    
效果圖：![Renderings](https://github.com/SpecialCyCi/AndroidResideMenu/raw/master/2.gif)    

1. FloatingActionMenu-Animation  
扩展FloatingActionMenu库，自定义菜单图标，动画滚动时
项目地址: https://github.com/toanvc/FloatingActionMenu-Animation  
效果图: ![Renderings](https://github.com/toanvc/FloatingActionMenu-Animation/raw/master/screenshots/scale.gif)

<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  


#### 四、ViewPager 、Gallery  
1. Android-ViewPagerIndicator  
配合ViewPager使用的Indicator，支持各種位置和樣式  
項目地址：https://github.com/JakeWharton/Android-ViewPagerIndicator  
Demo地址：https://play.google.com/store/apps/details?id=com.viewpagerindicator.sample  
APP示例：太多了。。  
   
1. JazzyViewPager  
支持Fragment切換動畫的ViewPager，動畫包括轉盤、淡入淡出、翻頁、層疊、旋轉、方塊、翻轉、放大縮小等  
項目地址：https://github.com/jfeinstein10/JazzyViewPager  
Demo地址：https://github.com/jfeinstein10/JazzyViewPager/blob/master/JazzyViewPager.apk?raw=true  
效果類似桌面左右切換的各種效果，不過桌面並非用ViewPager實現而已  
   
1. Android-DirectionalViewPager  
支持橫向和縱向(垂直)的ViewPager  
項目地址：https://github.com/JakeWharton/Android-DirectionalViewPager  
Demo地址：https://market.android.com/details?id=com.directionalviewpager.sample  
   
1. android-pulltorefresh  
支持下拉刷新的ViewPager  
項目地址：https://github.com/chrisbanes/Android-PullToRefresh  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/pull-to-refreshview-demo.apk?raw=true  
APP示例：新浪微博各個頁面  
   
1. FancyCoverFlow  
支持Item切換動畫效果的類似Gallery View  
項目地址：https://github.com/davidschreiber/FancyCoverFlow  
Demo地址：https://play.google.com/store/apps/details?id=at.technikum.mti.fancycoverflow.samples  
效果圖：![Renderings](https://github-camo.global.ssl.fastly.net/ef5ced52b7b54652b50499521ed797c0188c7a6b/687474703a2f2f64617669647363687265696265722e6769746875622e696f2f46616e6379436f766572466c6f772f73637265656e73686f74322e706e67)  
   
1. AndroidTouchGallery  
支持雙擊或雙指縮放的Gallery(用ViewPager實現)，相比下面的PhotoView，在被放大後依然能滑到下一個item，並且支持直接從url和文件中獲取圖片，  
項目地址：https://github.com/Dreddik/AndroidTouchGallery  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/touch-gallery-demo.apk?raw=true  
APP示例：類似微信中查看聊天記錄圖片時可雙擊放大，並且放大情況下能正常左右滑動到前後圖片  
   
1. Android Auto Scroll ViewPager  
Android自動滾動 輪播循環的ViewPager  
項目地址：https://github.com/Trinea/android-auto-scroll-view-pager  
Demo地址：https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
文檔介紹：https://www.trinea.cn/android/auto-scroll-view-pager/  

1. Salvage view  
帶View緩存的Viewpager PagerAdapter，很方便使用  
項目地址：https://github.com/JakeWharton/salvage  
  
1. Android PagerSlidingTabStrip  
配合ViewPager使用的Indicator，支持ViewPager Scroll時Indicator聯動  
項目地址：https://github.com/astuetz/PagerSlidingTabStrip  
Demo地址：https://play.google.com/store/apps/details?id=com.astuetz.viewpager.extensions.sample  

1. SmartTabLayout    
自定義的Tab title strip，基於Google Samples中的android-SlidingTabBasic項目，滑動時Indicator可平滑過渡.    
項目地址：https://github.com/ogaclejapan/SmartTabLayout    
Demo地址：https://play.google.com/store/apps/details?id=com.ogaclejapan.smarttablayout.demo    
效果圖：![Renderings](https://raw.githubusercontent.com/ogaclejapan/SmartTabLayout/master/art/demo1.gif)    

1. SmartTabLayout
自定義的Tab title strip，基於Google Samples中的android-SlidingTabBasic項目，滑動時Indicator可平滑過渡.
項目地址：https://github.com/ogaclejapan/SmartTabLayout
Demo地址：https://play.google.com/store/apps/details?id=com.ogaclejapan.smarttablayout.demo
效果圖：![Renderings](https://raw.githubusercontent.com/ogaclejapan/SmartTabLayout/master/art/demo1.gif)

1. ViewPager3D效果
項目地址：https://github.com/inovex/ViewPager3D
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>


1. AnimaTabsview
仿網易雲音樂標簽切換的動畫,帶透明小三角
項目地址：https://github.com/wuyexiong/transparent-over-animtabsview
在線演示：http://v.youku.com/v_show/id_XNzA4MjY5NjA0.html

1. LoopingViewPager
無限循環的ViewPager
項目地址：https://github.com/imbryk/LoopingViewPager

1. android_page_curl
翻書卷曲效果
項目地址：https://github.com/harism/android_page_curl
APP示例：iReader
在線演示：https://www.youtube.com/watch?v=iwu7P5PCpsw

1. ViewPagerIndicator
簡化並實現android的TabHost效果，頂部滑動tab，引導頁，支持自定義tab樣式,自定義滑動塊樣式和位置,自定義切換tab的過渡動畫,子界面的預加載和界面緩存,設置界面是否可滑動
項目地址：https://github.com/LuckyJayce/ViewPagerIndicator

1. ScreenSlideIndicator
輕量級的圓形 Indicadtor，位置可以自由調整，不會對 ViewPager 產生任何影響。
項目地址：[ScreenSlidePager](https://github.com/LyndonChin/Android-ScreenSlidePager)
效果圖：
![](https://raw.githubusercontent.com/LyndonChin/Android-ScreenSlidePager/master/screenslidepager.gif)

1. ViewPager3D效果    
項目地址：https://github.com/inovex/ViewPager3D 

1. AnimaTabsview
仿網易雲音樂標簽切換的動畫,帶透明小三角    
項目地址：https://github.com/wuyexiong/transparent-over-animtabsview    
在線演示：http://v.youku.com/v_show/id_XNzA4MjY5NjA0.html    

1. LoopingViewPager    
無限循環的ViewPager    
項目地址：https://github.com/imbryk/LoopingViewPager    

1. android_page_curl    
翻書卷曲效果    
項目地址：https://github.com/harism/android_page_curl    
APP示例：iReader    
在線演示：https://www.youtube.com/watch?v=iwu7P5PCpsw    

1. ViewPagerIndicator    
簡化並實現android的TabHost效果，頂部滑動tab，引導頁，支持自定義tab樣式,自定義滑動塊樣式和位置,自定義切換tab的過渡動畫,子界面的預加載和界面緩存,設置界面是否可滑動    
項目地址：https://github.com/LuckyJayce/ViewPagerIndicator    

1. ScreenSlideIndicator    
輕量級的圓形 Indicadtor，位置可以自由調整，不會對 ViewPager 產生任何影響。    
項目地址：[ScreenSlidePager](https://github.com/LyndonChin/Android-ScreenSlidePager)    
效果圖：    
![](https://raw.githubusercontent.com/LyndonChin/Android-ScreenSlidePager/master/screenslidepager.gif)    

1. RecyclerViewPager    
完全繼承自RecyclerView，可以自定義觸發翻頁的距離，可自定義翻頁速度，支持垂直方向的ViewPager，支持Fragment。    
項目地址：[RecyclerViewPager](https://github.com/lsjwzh/RecyclerViewPager)    
效果圖：    
![](https://github.com/lsjwzh/RecyclerViewPager/blob/master/fragment.gif)
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目录" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

#### 五、GridView  
1. StaggeredGridView  
允許非對齊行的GridView，類似Pinterest的瀑布流，並且跟ListView一樣自帶View緩存，繼承自ViewGroup  
項目地址：https://github.com/maurycyw/StaggeredGridView  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/staggered-gridview-demo.apk?raw=true  
APP示例：Pinterest等  
   
1. AndroidStaggeredGrid  
允許非對齊行的GridView，類似Pinterest的瀑布流，繼承自AbsListView  
項目地址：https://github.com/etsy/AndroidStaggeredGrid  
APP示例：Pinterest等  
   
1. PinterestLikeAdapterView  
允許非對齊行的GridView，類似Pinterest的瀑布流，允許下拉刷新  
項目地址：https://github.com/GDG-Korea/PinterestLikeAdapterView  
APP示例：Pinterest等  
   
1. DraggableGridView  
Item可拖動交換位置的GridView，實際是自己繼承ViewGroup實現，類似桌面的單屏效果，可屏幕自動上下滾動進行Item移動交換，多屏效果見下面PagedDragDropGrid  
項目地址：https://github.com/thquinn/DraggableGridView  
Demo地址：https://github.com/thquinn/DraggableGridView/blob/master/bin/DraggableGridViewSample.apk?raw=true  
也可自定義item的寬高和每行的個數，同時修改了交換邏輯，當移動到另壹個item時就進行交換，並刪除滾動邏輯。  
項目地址：[DraggableGridView](https://github.com/andyken/DraggableGridView)  
效果圖：  
![Renderings](https://github.com/andyken/DraggableGridView/blob/master/sample/sample.gif)

1. DividedDraggableView
壹個帶有分割區域的可拖動 view ,可屏幕自動上下滾動進行 Item 移動交換。
項目地址：https://github.com/andyken/DividedDraggableView
效果圖：
![Renderings](https://github.com/andyken/DividedDraggableView/blob/master/app/sample.gif)

1. StickyGridHeaders  
GroupName滑動到頂端時會固定不動直到另外一個GroupName到達頂端的GridView  
項目地址：https://github.com/TonicArtos/StickyGridHeaders     
效果圖：![Renderings](https://github-camo.global.ssl.fastly.net/90b57e9383704c400706545225d439e057c6fcc0/687474703a2f2f342e62702e626c6f6773706f742e636f6d2f2d535f4262685758367754592f55517057306377554745492f41414141414141414776552f7a7a4a586a2d50635662592f73313630302f73637265656e2d6c616e6473636170652d736d616c6c65722e706e67)    

1. PagedDragDropGrid  
Item可拖動交換位置、拖動刪除的自定義控件，實際是自己繼承ViewGroup實現，類似桌面的多屏效果，可拖動到屏幕邊緣，屏幕自動左右滾動進行Item移動交換，可拖動進行刪除，單屏效果見上面DraggableGridView  
項目地址：https://github.com/mrKlar/PagedDragDropGrid  
Demo視頻：http://youtu.be/FYTSRfthSuQ  

1. Android-DraggableGridViewPager  
Item可拖動交換位置的GridView，實際是自己繼承ViewGroup實現，類似桌面的多屏效果，可屏幕自動左右滾動進行Item移動交換，單屏效果見上面DraggableGridView  
項目地址：https://github.com/zzhouj/Android-DraggableGridViewPager  
Demo地址：https://github.com/Trinea/trinea-download/blob/master/draggable-grid-viewpager-demo.apk?raw=true

1. GridView with Header and Footer    
和`ListView`一樣帶有頭部和底部，用法也一樣簡單    
項目地址：https://github.com/liaohuqiu/android-GridViewWithHeaderAndFooter    
效果圖：![Screen Shot](https://raw.githubusercontent.com/liaohuqiu/android-GridViewWithHeaderAndFooter/master/screen-shot.png)    
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 六、ImageView  
1. PhotoView  
支持雙擊或雙指縮放的ImageView，在ViewPager等Scrolling view中正常使用，相比上面的AndroidTouchGallery，不僅支持ViewPager，同時支持單個ImageView  
項目地址：https://github.com/chrisbanes/PhotoView  
Demo地址：https://play.google.com/store/apps/details?id=uk.co.senab.photoview.sample  
APP示例：photup  
   
1. android-gif-drawable  
支持gif顯示的view，用jni實現的，編譯生成so庫後直接xml定義view即可，而且本身不依賴于其他開源項目所以相對下面的ImageViewEx簡單的多   
項目地址：https://github.com/koral--/android-gif-drawable  
  
1. ImageViewEx  
支持Gif顯示的ImageView  
項目地址：https://github.com/frapontillo/ImageViewEx  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/imageviewex-demo.apk?raw=true  
依賴很多，編譯過程很繁瑣!|_|!
   
1. RoundedImageView  
帶圓角的ImageView  
項目地址：https://github.com/vinc3m1/RoundedImageView  
效果圖：![Renderings](https://raw.github.com/makeramen/RoundedImageView/master/screenshot.png)  
   
1. ColorArt  
根據圖片的均色設置背景色顯示文字和圖片，類似itune11中效果  
項目地址：https://github.com/MichaelEvans/ColorArt  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/color-art-demo.apk?raw=true  
   
1. CircleImageView  
圓形的ImageView  
項目地址：https://github.com/hdodenhof/CircleImageView  
效果圖：![Renderings](https://raw.github.com/hdodenhof/CircleImageView/master/screenshot.png)  
  
1. ImageViewZoom  
支持放大和平移的ImageView   
項目地址：https://github.com/sephiroth74/ImageViewZoom  
APP示例：https://play.google.com/store/apps/details?id=com.aviary.android.feather  
  
1. KenBurnsView  
實現Ken Burns effect效果，達到身臨其境效果的ImageView   
項目地址：https://github.com/flavioarfaria/KenBurnsView  

1. CustomShapeImageView    
各種形狀的ImageView, 相比上面的圓形ImageView，多了更多形狀    
項目地址：https://github.com/MostafaGazar/CustomShapeImageView     
效果圖：![Renderings](https://raw.github.com/MostafaGazar/CustomShapeImageView/master/Screenshot_2013-11-05-23-08-12.png)   
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 七、ProgressBar  
1. SmoothProgressBar  
水平進度條  
項目地址：https://github.com/castorflex/SmoothProgressBar  
Demo地址：https://play.google.com/store/apps/details?id=fr.castorflex.android.smoothprogressbar.sample  
   
1. ProgressWheel  
支持進度顯示的圓形ProgressBar  
項目地址：https://github.com/Todd-Davies/ProgressWheel  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/progress-wheel-demo.apk?raw=true  
   
1. android-square-progressbar  
在圖片周圍顯示進度  
項目地址：https://github.com/mrwonderman/android-square-progressbar  
Demo地址：https://play.google.com/store/apps/details?id=net.yscs.android.square_progressbar_example  
APP示例：square  
效果圖：![Renderings](https://googledrive.com/host/0BwESwPCuXtw7eExwSFVLQkR2TTg/newscreen1.png)  
   
1. HoloCircularProgressBar  
Android4.1 時鍾App樣式  
項目地址：https://github.com/passsy/android-HoloCircularProgressBar  
APP示例：Android4.1時鍾App  
效果圖：![Renderings](https://raw.github.com/passsy/android-HoloCircularProgressBar/master/raw/screenshot1.png)  
  
1. ProgressButton  
通過圖釘的不同狀態顯示進度     
項目地址：https://github.com/f2prateek/progressbutton   
文檔介紹：http://f2prateek.com/progressbutton/   
效果圖：![Renderings](http://f2prateek.com/progressbutton/static/states.png)  

1. GoogleProgressBar  
類似google 多個圓形卡片翻轉的progressBar   
項目地址：https://github.com/jpardogo/GoogleProgressBar   
效果圖：![Renderings](https://raw.githubusercontent.com/jpardogo/GoogleProgressBar/master/art/GoogleProgressBar.gif)  

1. TH-ProgressButton  
帶圓形進度顯示的按鈕   
項目地址；https://github.com/torryharris/TH-ProgressButton    
效果圖：![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot1.png)  	![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot2.png)  	![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot3.png)  	![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot4.png)  
  
1. NumberProgressBar  
帶數字進度的進度條     
項目地址：https://github.com/daimajia/NumberProgressBar   
效果圖：![Renderings](https://camo.githubusercontent.com/0c92568af7ec4e04e2e1503acdd2ca99854ab0b5/687474703a2f2f7777332e73696e61696d672e636e2f6d773639302f36313064633033346a77316566797264386e376937673230637a30326d7135662e676966)  

1. CircularProgressDrawable  
帶圓形進度顯示的進度條    
項目地址：https://github.com/Sefford/CircularProgressDrawable  
效果圖：![Renderings](https://raw.githubusercontent.com/Sefford/CircularProgressDrawable/master/overshoot.gif)    

1. Android-RoundCornerProgressBar  
Android 圓角 ProgressBar，可自定義圓角顏色和半徑，包括帶 Icon 和不帶 Icon 兩種類型。    
項目地址：https://github.com/akexorcist/Android-RoundCornerProgressBar  
效果圖：    
![Renderings](https://raw.githubusercontent.com/akexorcist/Android-RoundCornerProgressBar/master/image/screenshot_02.png)      
1. circular-progress-button  
帶進度顯示的Button    
項目地址：https://github.com/dmytrodanylyk/circular-progress-button  
效果圖：    
![Renderings](https://raw.githubusercontent.com/dmytrodanylyk/circular-progress-button/master/screenshots/intro.gif)      

1. WaveView  
壹個波紋效果的 View，可用來做 ProgressBar    
項目地址：https://github.com/john990/WaveView  
Demo地址：https://raw.github.com/john990/WaveView/master/screenshot%26apk/demo.unaligned.apk  
效果圖：    
![Renderings](https://camo.githubusercontent.com/60722e9d4f2d2daa78a8650cb27a32adea82bdd4/68747470733a2f2f7261772e6769746875622e636f6d2f6a6f686e3939302f57617665566965772f6d61737465722f73637265656e73686f7425323661706b2f73637265656e73686f742e676966)  

1. MaterialLoadingProgressBar    
抽取自SwipeRefreshLayout的Material Design進度指示器    
項目地址：https://github.com/lsjwzh/MaterialLoadingProgressBar    
效果圖：![Renderings](https://github.com/lsjwzh/MaterialLoadingProgressBar/raw/master/screen.gif)    
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

1. LoadingDrawable
壹些酷炫的android加載動畫，可以與任何組件配合使用作為加載的組件或者ProgressBar。<br>
項目地址：https://github.com/dinuscxj/LoadingDrawable
效果圖：<br/>
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/AnimalDrawable.gif?width=300)
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/SceneryDrawable.gif?width=300)
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/CircleJumpDrawable.gif?width=300)
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/CircleRotateDrawable.gif?width=300)

#### 八、TextView  
包括TextView及所有繼承自TextView控件，如EditText、Button、RadioButton  

1. android-flowtextview  
文字自動環繞其他View的Layout  
項目地址：https://code.google.com/p/android-flowtextview/  
效果圖：http://i949.photobucket.com/albums/ad332/vostroman1500/1.png  
  
1. Android Form EditText  
驗證輸入合法性的編輯框，支持輸入、英文、ip、url等多種正則驗證  
項目地址：https://github.com/vekexasia/android-edittext-validator  
Demo地址：https://play.google.com/store/apps/details?id=com.andreabaccega.edittextformexample  

1. Emojicon  
支持emojis的TextView和EditText    
項目地址：https://github.com/rockerhieu/emojicon  
文檔地址：http://rockerhieu.com/emojicon/    

1. android-circlebutton  
Android圓形按鈕，實際實現是繼承自ImageView  
項目地址：https://github.com/markushi/android-circlebutton   
Demo地址：https://github.com/markushi/android-circlebutton/blob/master/example/example.apk    

1. Segmented Radio Buttons for Android  
iOS’s segmented controls的實現  
項目地址：https://github.com/vinc3m1/android-segmentedradiobutton  
Demo地址：https://github.com/thquinn/DraggableGridView/blob/master/bin/DraggableGridViewSample.apk?raw=true  
效果圖：![Renderings](https://raw.github.com/vinc3m1/android-segmentedradiobutton/master/screens/segmentedradio.png)  

1. Chips EditText Library  
支持國家名字聯想從而選擇顯示該國國旗的EditText，實際就是通過SpannableStringBuilder實現  
項目地址：https://github.com/kpbird/chips-edittext-library  
Demo地址：https://github.com/kpbird/chips-edittext-library/tree/master/ChipsEditTextDemo/bin  

1. AutoFitTextView
可固定邊界內容字體大小自適應的TextView    
項目地址：https://github.com/grantland/android-autofittextview  

1. Shimmer for Android  
文字發淡光的TextView  
項目地址：https://github.com/RomainPiel/Shimmer-android  

1. Titanic   
可以顯示水位上升下降(不知道該怎麽描述 囧)的TextView    
項目地址：https://github.com/RomainPiel/Titanic    
效果圖：![Renderings](https://github.com/RomainPiel/Titanic/raw/master/titanic.gif)   

1. android-iconify  
提供帶Icon的TextView,Menu,Button等  
項目地址：https://github.com/JoanZapata/android-iconify  

1. Calligraphy    
讓我們在android開發中使用自定義字體變得更加簡單      
項目地址 ：https://github.com/chrisjenx/Calligraphy    
效果圖：![Renderings](https://github.com/chrisjenx/Calligraphy/raw/master/screenshot.png)  

1. CreditsRoll  
類似星球大戰字幕效果的TextView  
項目地址：https://github.com/frakbot/CreditsRoll  

1. android-process-buton  
帶加載或提交進度的Button  
項目地址：https://github.com/dmytrodanylyk/android-process-buton  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. MoneyTextView  
壹個支持加法運算的金額輸入TextView  
項目地址：https://github.com/andyken/MoneyTextView  
效果圖：  
![Renderings](https://github.com/andyken/MoneyTextView/blob/master/sample/sample1.gif)  

#### 九、ScrollView  
1. Discrollview  
支持滾動時Item淡入淡出，平移，縮放效果的ScrollView  
項目地址：https://github.com/flavienlaurent/discrollview   
Demo地址：https://github.com/flavienlaurent/discrollview/raw/master/sample.apk    

1. PullScrollView   
仿照新浪微博Android客戶端個人中心的ScrollView，下拉背景伸縮回彈效果。  
項目地址：https://github.com/MarkMjw/PullScrollView    
效果圖：![Renderings](https://raw.github.com/MarkMjw/PullScrollView/master/Screenshots/1.png)  

1. ParallaxScrollView  
支持視差滾動的ScrollView ，背景圖片的滾動速度小于ScrollView中子控件的滾動速度    
項目地址：https://github.com/chrisjenx/ParallaxScrollView    
示例APK地址：https://github.com/chrisjenx/ParallaxScrollView/downloads     
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a> 

#### 十、TimeView  
包括TimePicker、DatePicker、CalendarView、Clock等時間相關控件  

1. android-times-square  
Android日曆時間部件，支持選取單個日期，多個日期，及日期區間段和對話框形式顯示  
項目地址：https://github.com/square/android-times-square  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/times-square-demo.apk?raw=true  
   
1. android-calendar-card  
日曆  
項目地址：https://github.com/kenumir/android-calendar-card  
Demo地址：https://play.google.com/store/apps/details?id=com.wt.calendarcardsample  
效果圖：![Renderings](https://raw.github.com/kenumir/android-calendar-card/master/calendar-card-sample/_work/device-2013-10-12-151801.png)  
   
1. AndroidWheel  
Android Wheel支持城市、多種日期時間、密碼、圖片  
項目地址：https://github.com/sephiroth74/AndroidWheel  
效果圖：![Renderings](http://farm6.staticflickr.com/5532/11621528786_220c040ba5_o.jpg)  
  
1. GoogleDateTimePickers  
時間選擇部件  
項目地址：https://github.com/Mirkoddd/GoogleDateTimePickers  
文檔地址：https://play.google.com/store/apps/details?id=com.mirko.sample&hl=it  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十一、TipView  
包括Toast、角標、UndoBar等提示性控件  

1. Crouton  
豐富樣式的Toast，允許alert、comfirm、info樣式及點擊消失樣式，允許設置Toast顯示時間，允許自定義View。 本文32. SuperToasts爲其擴展版  
項目地址：https://github.com/keyboardsurfer/Crouton  
Demo地址：http://play.google.com/store/apps/details?id=de.keyboardsurfer.app.demo.crouton  
   
1. supertooltips  
帶動畫效果的Tips顯示  
項目地址：https://github.com/nhaarman/supertooltips  
Demo地址：https://play.google.com/store/apps/details?id=com.haarman.supertooltips  
   
1. Android ViewBadger  
爲其他View添加角標等  
項目地址：https://github.com/jgilfelt/android-viewbadger  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/android-viewbadger.apk?raw=true  
效果圖：![Renderings](https://github-camo.global.ssl.fastly.net/a705a3e88c75ae2394943bd7c56f725697616ea8/687474703a2f2f7777772e6a65666667696c66656c742e636f6d2f766965776261646765722f76622d31612e706e67)  
 
   
1. SuperToasts  
更豐富樣式的toast，支持Button、Progress、Horizontal Progress樣式、支持進入動畫、支持撤銷及其動畫設置    
項目地址：https://github.com/JohnPersano/SuperToasts  
Demo地址：https://play.google.com/store/apps/details?id=com.supertoastsdemo  
效果圖：![SuperButtonToast](http://i1331.photobucket.com/albums/w597/JohnPersano/supertoasts_githubimage_zps8a5ceb7c.png)  
  
1. UndoBar  
屏幕底部顯示取消或是確認的PopupWindows  
項目地址：https://github.com/soarcn/UndoBar  
效果圖：![Renderings](https://github.com/soarcn/UndoBar/blob/master/art/redo.png?raw=true)  
   
1. UndoBar  
屏幕底部顯示取消或是確認某操作  
項目地址：https://github.com/jenzz/Android-UndoBar  
效果圖：![Renderings](https://raw.github.com/jenzz/Android-UndoBar/master/assets/Screenshot2.png)  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十二、FlipView  
1. android-flip  
類似Flipboard翻轉動畫的實現  
項目地址：https://github.com/openaphid/android-flip  
Demo地址：https://github.com/openaphid/android-flip/blob/master/FlipView/Demo/APK/Aphid-FlipView-Demo.apk?raw=true  
APP示例：flipboard  
   
1. FlipImageView  
支持x、y、z及動畫選擇的翻轉動畫的實現  
項目地址：https://github.com/castorflex/FlipImageView  
Demo地址：https://play.google.com/store/apps/details?id=fr.castorflex.android.flipimageview  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十三、ColorPickView  
1. ColorPickerView  
顔色選擇器，支持PopupWindows或新的Activity中打開  
項目地址：https://code.google.com/p/color-picker-view/  
效果圖：![Renderings](http://oi41.tinypic.com/33c6mm8.jpg)  
   
1. HoloColorPicker  
顔色選擇器  
項目地址：https://github.com/LarsWerkman/HoloColorPicker  
Demo地址：https://docs.google.com/file/d/0BwclyDTlLrdXRzVnTGJvTlRfU2s/edit  
  
1. ColorPickerPreference  
顔色選擇器  
項目地址：https://github.com/attenzione/android-ColorPickerPreference  
效果圖：![Renderings](https://github.com/attenzione/android-ColorPickerPreference/raw/master/screen_2.png)  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十四、GraphView  
1. achartengine  
強大的圖表繪制工具，支持折線圖、面積圖、散點圖、時間圖、柱狀圖、條圖、餅圖、氣泡圖、圓環圖、範圍（高至低）條形圖、撥號圖/表、立方線圖及各種圖的結合  
項目地址：https://code.google.com/p/achartengine/  
官方網站：http://www.achartengine.org/  
效果圖：![Renderings](http://www.achartengine.org/dimages/average_temperature.png)  
http://www.achartengine.org/dimages/sales_line_and_area_chart.png  
http://www.achartengine.org/dimages/temperature_range_chart.png  
http://www.achartengine.org/dimages/combined_chart.png  
http://www.achartengine.org/dimages/budget_chart.png  
APP示例：Wordpress Android，Google Analytics  
   
1. GraphView  
繪制圖表和曲線圖的View，可用于Android上的曲形圖、柱狀圖、波浪圖展示  
項目地址：https://github.com/jjoe64/GraphView  
Demo工程：https://github.com/jjoe64/GraphView-Demos  
Demo地址：https://play.google.com/store/apps/details?id=com.sothree.umano  
APP示例：Wordpress Android，Google Analytics  
  
1. HoloGraphLibrary  
繪制現狀圖、柱狀圖、餅狀圖    
項目地址：https://bitbucket.org/danielnadeau/holographlibrary/src  
文檔介紹：https://bitbucket.org/danielnadeau/holographlibrary/wiki/Home  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十五、UI Style  
不同樣式的系統UI風格，如IOS、Bootstrap風格
   
1. UITableView  
ios風格控件，包括Button、ListView、TableView  
項目地址：https://github.com/thiagolocatelli/android-uitableview  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/ui-tableview-demo.apk?raw=true  
   
1. ATableView  
ios風格控件  
項目地址：https://github.com/dmacosta/ATableView  
Demo地址：https://play.google.com/store/apps/details?id=com.nakardo.atableview.demo  
   
1. Cards-UI  
卡片式View，支持單個卡片，item爲卡片的ListView  
項目地址：https://github.com/afollestad/Cards-UI  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/cards-ui-demo.apk?raw=true  
   
1. cardslib  
卡片式View，支持單個卡片，item爲卡片的ListView和GridView  
項目地址：https://github.com/gabrielemariotti/cardslib  
Demo地址：https://play.google.com/store/apps/details?id=it.gmariotti.cardslib.demo  
  
1. Android-Bootstrap  
Bootstrap 風格的按鈕    
項目地址： https://github.com/Bearded-Hen/Android-Bootstrap  
效果圖：![Renderings](https://raw.github.com/Bearded-Hen/Android-Bootstrap/master/images/device_image.png)   
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十六、其他     
1. SwipeBackLayout  
左右或向上滑動返回的Activity  
項目地址：https://github.com/Issacw0ng/SwipeBackLayout  
Demo地址：https://play.google.com/store/apps/details?id=me.imid.swipebacklayout.demo  
APP示例：知乎  
   
1. android-styled-dialogs  
可自定義樣式的dialog，默認與Holo主題樣式一致，在Android2.2以上同一樣式  
項目地址：https://github.com/inmite/android-styled-dialogs  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/styled-dialogs-demo.apk?raw=true  
   
1. Android Sliding Up Panel  
可拖動的View，能在當前Activity上扶起一個可拖動的Panel  
項目地址：https://github.com/umano/AndroidSlidingUpPanel  
Demo地址：https://play.google.com/store/apps/details?id=com.sothree.umano  
APP示例：Google Music精簡播放欄  
   
1. AndroidWheel  
Android Wheel支持城市、多種日期時間、密碼、圖片  
項目地址：https://github.com/sephiroth74/AndroidWheel  
效果圖：![Renderings](http://farm6.staticflickr.com/5532/11621528786_220c040ba5_o.jpg)  
   
1. TableFixHeaders  
第一列固定的Table  
項目地址：https://github.com/InQBarna/TableFixHeaders  
Demo地址：http://bit.ly/13buAIq  
   
1. Inscription  
可用于展示應用change和new feature信息  
項目地址：https://github.com/MartinvanZ/Inscription  
   
1. ActivityTransition  
Activity切換動畫，包括漸變、flip、某個位置進入等等  
項目地址：https://github.com/ophilbert/ActivityTransition  
使用介紹：https://github.com/jfeinstein10/JazzyViewPager/blob/master/JazzyViewPager.apk?raw=true  
效果圖：類似桌面左右切換的各種效果，不過桌面並非用ViewPager實現而已  
   
1. GlowPadBackport  
將Android4.2的鎖屏界面解鎖擴展到Android1.6及1.6+  
項目地址：https://github.com/rock3r/GlowPadBackport  
Demo地址：https://play.google.com/store/apps/details?id=net.sebastianopoggi.samples.ui.GlowPadSample  
效果圖：![Renderings](https://lh6.ggpht.com/U070b6Lh6cVsVwx4jN-5nq0xqiB1PBzrYABPeJIEe2hZQ5UWOxc-FDUG77wADelToHA=h310-rw)  

1. GlowPadView  
Android4鎖屏界面解鎖  
項目地址：https://github.com/nadavfima/GlowPadView  
效果圖：https://raw.github.com/nadavfima/GlowPadView/master/example.png  
   
1. android-lockpattern  
Android的圖案密碼解鎖  
項目地址：https://code.google.com/p/android-lockpattern/  
Demo地址：https://play.google.com/store/apps/details?id=group.pals.android.lib.ui.lockpattern.demo  
使用介紹：https://code.google.com/p/android-lockpattern/wiki/QuickUse  
示例APP：Android開機的圖案密碼解鎖，支付寶的密碼解鎖  
  
1. PatternLock  
另一個 Android 圖案解鎖庫  
項目地址：https://github.com/DreaminginCodeZH/PatternLock  
Demo地址：https://github.com/DreaminginCodeZH/PatternLock/raw/master/dist/sample.apk  
效果圖：![Renderings](https://github.com/DreaminginCodeZH/PatternLock/raw/master/image/sample_small.png)  
示例APP：Android開機的圖案密碼解鎖，支付寶的密碼解鎖  
  
1. RangeBar  
類似于SeekBar，不同的是可以選擇一個範圍內的值而不是單個值  
項目地址：https://github.com/edmodo/range-bar  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/range-bar-demo.apk?raw=true  
效果圖: ![Renderings](http://i.imgur.com/q85GhRjl.png)  

1. ChromeView  
利用Chromium實現的WebView，解決各個Android版本WebView不同的問題，同時利用最新Chrome代碼    
項目地址：https://github.com/pwnall/chromeview  
   
1. Android Slider Preference Library  
可添加到設置中的基于對話框的RankBar小部件  
項目地址：https://github.com/jayschwa/AndroidSliderPreference   

1. ShowcaseView library  
用于高亮顯示應用程序的特定部分，從而突出突出重點  
項目地址：https://github.com/amlcurran/ShowcaseView   

1. android-segmented-control  
Android上的Segmented Controls，相當于RadioButton組  
項目地址：https://github.com/hoang8f/android-segmented-control   
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. Spotlight  
Android图书馆点亮项目的教程或漫步等...  
項目地址：https://github.com/TakuSemba/Spotlight

效果圖: ![Renderings](https://raw.githubusercontent.com/takusemba/spotlight/master/arts/customTarget.gif)  

1. SpeedView  
Android的动态车速表和量规。 惊人，强大，多形 :zap:
項目地址: https://github.com/anastr/SpeedView   
效果圖:   
![Renderings](https://raw.githubusercontent.com/anastr/SpeedView/master/images/AwesomeSpeedometer.gif)  


## 第二部分 工具庫  
主要包括那些不錯的開發庫，包括依賴注入框架、圖片緩存、網絡相關、數據庫ORM建模、Android公共庫、Android 高版本向低版本兼容、多媒體相關及其他。  <a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
#### 一、依賴注入DI  
通過依賴注入減少View、服務、資源簡化初始化，事件綁定等重複繁瑣工作  

1. AndroidAnnotations(Code Diet)  
android快速開發框架  
項目地址：https://github.com/excilys/androidannotations  
文檔介紹：https://github.com/excilys/androidannotations/wiki  
官方網站：http://androidannotations.org/  
特點：(1) 依賴注入：包括view，extras，系統服務，資源等等  
(2) 簡單的線程模型，通過annotation表示方法運行在ui線程還是後台線程  
(3) 事件綁定：通過annotation表示view的響應事件，不用在寫內部類  
(4) REST客戶端：定義客戶端接口，自動生成REST請求的實現  
(5) 沒有你想象的複雜：AndroidAnnotations只是在在編譯時生成相應子類  
(6) 不影響應用性能：僅50kb，在編譯時完成，不會對運行時有性能影響。  
PS：與roboguice的比較：roboguice通過運行時讀取annotations進行反射，所以可能影響應用性能，而AndroidAnnotations在編譯時生成子類，所以對性能沒有影響  
   
1. roboguice  
幫你處理了很多代碼異常，利用annotation使得更少的代碼完成項目  
項目地址：https://github.com/roboguice/roboguice  
文檔介紹：https://github.com/roboguice/roboguice/wiki  
   
1. butterknife  
利用annotation幫你快速完成View的初始化，減少代碼  
項目地址：https://github.com/JakeWharton/butterknife  
文檔介紹：http://jakewharton.github.io/butterknife/  
   
1. Dagger  
依賴注入，適用于Android和Java  
項目地址：https://github.com/square/dagger  
文檔介紹：http://square.github.io/dagger/  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 二、圖片緩存  
1. Android-Universal-Image-Loader  
圖片緩存，目前使用最廣泛的圖片緩存，支持主流圖片緩存的絕大多數特性。  
項目地址：https://github.com/nostra13/Android-Universal-Image-Loader  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/universal-imageloader-demo.apk?raw=true  
文檔介紹：http://www.intexsoft.com/blog/item/74-universal-image-loader-part-3.html  
   
1. picasso  
square開源的圖片緩存  
項目地址：https://github.com/square/picasso  
文檔介紹：http://square.github.io/picasso/  
特點：(1)可以自動檢測adapter的重用並取消之前的下載  
(2)圖片變換  
(3)可以加載本地資源  
(4)可以設置占位資源  
(5)支持debug模式  
   
1. ImageCache  
圖片緩存，包含內存和Sdcard緩存  
項目地址：https://github.com/Trinea/AndroidCommon  
Demo地址：https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
文檔介紹：https://www.trinea.cn/android/android-imagecache/  
特點：(1)支持預取新圖片，支持等待隊列  
(2)包含二級緩存，可自定義文件名保存規則  
(3)可選擇多種緩存算法(FIFO、LIFO、LRU、MRU、LFU、MFU等13種)或自定義緩存算法  
(4)可方便的保存及初始化恢複數據  
(5)支持不同類型網絡處理  
(6)可根據系統配置初始化緩存等  

1. Cube ImageLoader  
阿里巴巴一些App使用的圖片加載組件，綜合了Android-Universal-Image-Loader 和 square 等組件優點，簡單易用。
項目地址：https://github.com/etao-open-source/cube-sdk  
Demo地址：https://github.com/liaohuqiu/cube-sdk/raw/master/cube-sdk-sample.apk  
文檔介绍：http://cube-sdk.liaohuqiu.net/  
效果圖：![Screen Shot](https://raw.githubusercontent.com/etao-open-source/cube-sdk/dev/screen-shot.png)
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 三、網絡相關  
1. Asynchronous Http Client for Android  
Android異步Http請求  
項目地址：https://github.com/loopj/android-async-http  
文檔介紹：http://loopj.com/android-async-http/  
特點：(1) 在匿名回調中處理請求結果  
(2) 在UI線程外進行http請求  
(3) 文件斷點上傳  
(4) 智能重試  
(5) 默認gzip壓縮  
(6) 支持解析成Json格式  
(7) 可將Cookies持久化到SharedPreferences  
   
1. android-query  
異步加載，更少代碼完成Android加載  
項目地址：https://github.com/androidquery/androidquery 或 https://code.google.com/p/android-query/  
文檔介紹：https://code.google.com/p/android-query/#Why_AQuery?  
Demo地址：https://play.google.com/store/apps/details?id=com.androidquery  
特點：https://code.google.com/p/android-query/#Why_AQuery?  
   
1. Async Http Client  
Java異步Http請求  
項目地址：https://github.com/AsyncHttpClient/async-http-client  
文檔介紹：http://sonatype.github.io/async-http-client/  
   
1. Ion  
支持圖片、json、http post等異步請求  
項目地址：https://github.com/koush/ion  
文檔介紹：https://github.com/koush/ion#more-examples  
   
1. HttpCache  
Http緩存  
項目地址：https://github.com/Trinea/AndroidCommon  
Demo地址：https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
文檔介紹：https://www.trinea.cn/android/android-http-cache  
特點是：(1) 根據cache-control、expires緩存http請求  
(2) 支持同步、異步Http請求  
(3) 在匿名回調中處理請求結果  
(4) 在UI線程外進行http請求  
(5) 默認gzip壓縮  
   
1. Http Request  
項目地址：https://github.com/kevinsawicki/http-request  
文檔介紹：https://github.com/kevinsawicki/http-request#examples  
   
1. okhttp  
square開源的http工具類  
項目地址：https://github.com/square/okhttp  
文檔介紹：http://square.github.io/okhttp/  
特點：(1) 支持SPDY( http://zh.wikipedia.org/wiki/SPDY )協議。SPDY協議是Google開發的基于傳輸控制協議的應用層協議，通過壓縮，多路複用(一個TCP鏈接傳送網頁和圖片等資源)和優先級來縮短加載時間。  
(2) 如果SPDY不可用，利用連接池減少請求延遲  
(3) Gzip壓縮  
(4) Response緩存減少不必要的請求  
   
1. Retrofit  
RESTFUL API設計  
項目地址：https://github.com/square/retrofit  
文檔介紹：http://square.github.io/retrofit/  
   
1. RoboSpice  
Android異步網絡請求工具，支持緩存、REST等等  
項目地址：https://github.com/stephanenicolas/robospice  
Demo地址：https://github.com/stephanenicolas/RoboDemo/downloads  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 四、數據庫 orm工具包  
orm的db工具類，簡化建表、查詢、更新、插入、事務、索引的操作  

1. greenDAO  
Android Sqlite orm的db工具類  
項目地址：https://github.com/greenrobot/greenDAO  
文檔介紹：http://greendao-orm.com/documentation/  
官方網站：http://greendao-orm.com/  
特點：(1) 性能佳  
(2) 簡單易用的API  
(3) 內存小好小  
(4) 庫大小小  
   
1. ActiveAndroid  
Android Sqlite orm的db工具類  
項目地址：https://github.com/pardom/ActiveAndroid  
文檔介紹：https://github.com/pardom/ActiveAndroid/wiki/_pages  
   
1. Sprinkles  
Android Sqlite orm的db工具類  
項目地址：https://github.com/emilsjolander/sprinkles  
文檔介紹：http://emilsjolander.github.io/blog/2013/12/18/android-with-sprinkles/  
特點：比較顯著的特點就是配合https://github.com/square/retrofit 能保存從服務器獲取的數據  
   
1. ormlite-android  
項目地址：https://github.com/j256/ormlite-android  
文檔介紹：http://ormlite.com/sqlite_java_android_orm.shtml   
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 五、Android公共庫  
1. Guava  
Google的基于java1.6的類庫集合的擴展項目，包括collections, caching, primitives support, concurrency libraries, common annotations, string processing, I/O等等. 這些高質量的API可以使你的JAVa代碼更加優雅，更加簡潔  
項目地址：https://code.google.com/p/guava-libraries/  
文檔介紹：https://code.google.com/p/guava-libraries/wiki/GuavaExplained  
   
1. Volley  
Google提供的網絡通信庫，使得網絡請求更簡單、更快速  
項目地址：https://android.googlesource.com/platform/frameworks/volley  
Github地址：https://github.com/mcxiaoke/android-volley    
文檔地址：http://commondatastorage.googleapis.com/io-2013/presentations/110%20-%20Volley-%20Easy,%20Fast%20Networking%20for%20Android.pdf  

1. AndroidCommon  
Android公共庫  
項目地址：https://github.com/Trinea/AndroidCommon  
Demo地址：https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
文檔介紹：https://www.trinea.cn/android/android-common-lib/  
包括：(1)緩存(圖片緩存、預取緩存、網絡緩存)  
(2) 公共View(下拉及底部加載更多ListView、底部加載更多ScrollView、滑動一頁Gallery)  
(3) Android常用工具類(網絡、下載、Android資源操作、shell、文件、Json、隨機數、Collection等等)  
   
1. shipfaster  
整合了Dagger Otto Retrofit Robolectric Picasso OkHttp，方便快速開發  
項目地址：https://github.com/pyricau/shipfaster  
   
1. CleanAndroidCode  
整合了Dagger Otto AndroidAnnotations，方便快速開發  
項目地址：https://github.com/pyricau/CleanAndroidCode  
我目前也在做框架選型方面的工作，不出意外後面也會出個跟4、5類似的項目  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 六、Android 高版本向低版本兼容  
1. ActionBarSherlock  
爲Android所有版本提供統一的ActionBar，解決4.0以下ActionBar的適配問題  
項目地址：https://github.com/JakeWharton/ActionBarSherlock  
Demo地址：https://play.google.com/store/apps/details?id=com.actionbarsherlock.sample.demos  
APP示例：太多了。。現在連google都在用  
   
1. Nine Old Androids  
將Android 3.0(Honeycomb)所有動畫API(ObjectAnimator ValueAnimator等)兼容到Android1.0  
項目地址：https://github.com/JakeWharton/NineOldAndroids  
Demo地址：https://play.google.com/store/apps/details?id=com.jakewharton.nineoldandroids.sample  
文檔介紹：http://nineoldandroids.com/  
   
1. HoloEverywhere  
將Android 3.0的Holo主題兼容到Android2.1++  
項目地址：https://github.com/Prototik/HoloEverywhere  
Demo地址：https://raw.github.com/Prototik/HoloEverywhere/repo/org/holoeverywhere/demo/2.1.0/demo-2.1.0.apk  
文檔介紹：http://android-developers.blogspot.com/2012/01/holo-everywhere.html  
   
1. SherlockNavigationDrawer  
將Android NavigationDrawer和ActionbarSherlock結合，解決4.0以下NavigationDrawer的適配問題  
項目地址：https://github.com/tobykurien/SherlockNavigationDrawer  

1. Notifications4EveryWhere  
將Android 4.1的兼容到Android2.2++  
項目地址：https://github.com/youxiachai/Notifications4EveryWhere  
NavigationDrawer文檔地址：http://developer.android.com/training/implementing-navigation/nav-drawer.html  

1. Android Switch Widget Backport  
將Android Switch和SwitchPreference的兼容到Android2.1++  
項目地址：https://github.com/BoD/android-switch-backport  
Demo地址：https://play.google.com/store/apps/details?id=org.jraf.android.backport.switchwidget.sample  
文檔介紹：https://github.com/BoD/android-switch-backport#using-the-switch  

1. android-datepicker  
將Android 4.0的datepicker兼容到Android2.2++  
項目地址：https://github.com/SimonVT/android-datepicker  

1. GlowPadBackport  
Android 4.2的GlowPadView向後適配到API4以上  
項目地址：https://github.com/frakbot/GlowPadBackport 
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 七、多媒體相關  
1. cocos2d-x  
跨平台的2d遊戲框架，支持Android、IOS、Linux、Windows等衆多平台  
項目地址：https://github.com/cocos2d/cocos2d-x  
文檔介紹：http://www.cocos2d-x.org/wiki  
官方網站：http://www.cocos2d-x.org/  
   
1. Vitamio  
是一款Android與iOS平台上的全能多媒體開發框架  
項目地址：https://github.com/yixia/VitamioBundle  
網站介紹：http://www.vitamio.org/docs/  
特點：(1) 全面支持硬件解碼與GPU渲染  
(2) 能夠流暢播放720P甚至1080P高清MKV，FLV，MP4，MOV，TS，RMVB等常見格式的視頻  
(3) 在Android與iOS上跨平台支持 MMS, RTSP, RTMP, HLS(m3u8)等常見的多種視頻流媒體協議，包括點播與直播。  
   
1. PhotoProcessing  
利用ndk處理圖片庫，支持Instafix、Ansel、Testino、XPro、Retro、BW、Sepia、Cyano、Georgia、Sahara、HDR、Rotate(旋轉)、Flip(翻轉)等各種特效  
項目地址：https://github.com/lightbox/PhotoProcessing  
Demo地址：https://github.com/Trinea/TrineaDownload/blob/master/photo-processing.apk?raw=true  
   
1. Android StackBlur  
圖片模糊效果工具類  
項目地址：https://github.com/kikoso/android-stackblur  
Demo地址：https://github.com/kikoso/android-stackblur/blob/master/StackBlurDemo/bin/StackBlurDemo.apk?raw=true  
文檔介紹：https://github.com/kikoso/android-stackblur#usage  

1. Bitmap Smart Clipping using OpenCV  
圖片智能裁剪保留重要部分顯示   
項目地址：https://github.com/beartung/tclip-android  
利用淘寶的 http://code.taobao.org/p/tclip/ 庫完成  
一淘玩客正在使用的圖片裁剪，自動識別圖片中的重要區域，並且在圖片裁剪時保留重要區域  
特點：(1). 能進行人臉識別。圖片中有人臉，將自動視爲人臉區域爲重要區域，將不會被裁剪掉  
(2).自動其它重要區域。如果圖片中未識別出人臉，則會根據特征分布計算出重區域  
   
1. Cropper  
圖片局部剪切工具，可觸摸控制選擇區域或旋轉  
項目地址：https://github.com/edmodo/cropper  
使用介紹：https://github.com/edmodo/cropper/wiki  
效果圖：![Renderings](https://github-camo.global.ssl.fastly.net/e4fde77bf41d4a60b234b4e268e5cfa8c17d9b6f/687474703a2f2f692e696d6775722e636f6d2f334668735467666c2e6a7067)  

1. android-crop  
圖片裁剪Activity  
項目地址：https://github.com/jdamcd/android-crop  
效果圖：![Renderings](https://github.com/jdamcd/android-crop/raw/master/screenshot.png)  

1. TileView  
可分塊顯示大圖，支持2D拖動、雙擊、雙指放大、雙指捏合  
項目地址：https://github.com/moagrius/TileView  
Demo地址：http://moagrius.github.io/TileView/TileViewDemo.apk  

1. BlurEffectForAndroidDesign  
圖片模糊效果  
項目地址：https://github.com/PomepuyN/BlurEffectForAndroidDesign  

1. android-eye  
PC端網頁查看同一局域網內的手機攝像頭內容，可以用來監控哦  
項目地址：https://github.com/Teaonly/android-eye  
Demo地址：https://play.google.com/store/apps/details?id=teaonly.droideye  

1. libpng for Android  
PNG圖片的jni庫，支持幾乎png的所有特性  
項目地址：https://github.com/julienr/libpng-android  
文檔地址：http://www.libpng.org/pub/png/libpng.html  

1. android-gpuimage    
基于GPU的圖片濾鏡    
項目地址：https://github.com/CyberAgent/android-gpuimage     

1. AndroidFaceCropper  
圖片臉部自動識別，將識別後的局部圖片返回  
項目地址：https://github.com/lafosca/AndroidFaceCropper  

1. Android Video Crop  
利用TextureView播放和剪切視頻，類似ImageView.setScaleType  
項目地址：https://github.com/dmytrodanylyk/android-video-crop  
Demo地址：https://github.com/lafosca/AndroidFaceCropper/releases/download/1.0/FaceCropper-sample-debug-unaligned.apk  
  
1. svg-android  
Android Svg矢量圖形支持  
項目地址：https://github.com/japgolly/svg-android https://github.com/japgolly/svg-android  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 八、事件總線(訂閱者模式)  
通過發布/訂閱事件解耦事件發送和接受，從而簡化應用程序組件(Activities, Fragments及後台線程)之間的通信  

1. EventBus  
greenrobot的開源項目  
項目地址：https://github.com/greenrobot/EventBus  
文檔介紹：https://github.com/greenrobot/EventBus#general-usage-and-api  
特點：(1) 支持在不同類型的線程中處理訂閱，包括發布所在線程，UI線程、單一後台線程、異步線程  
(2) 支持事件優先級定義，支持優先級高的訂閱者取消事件繼續傳遞，支持粘性事件，是不是跟系統的有序廣播、粘性廣播很像啊  
(3) 不是基于annotations  
(4) 性能更優  
(5) 體積小  
(6) 支持單例創建或創建多個對象  
(7) 支持根據事件類型訂閱  

1. Otto  
Square的開源項目，基于Guava的Android優化  
項目地址：https://github.com/square/otto  
文檔介紹：http://square.github.io/otto/  
[EventBus與Otto的功能及性能對比文檔](https://github.com/greenrobot/EventBus#comparison-with-squares-otto)  
[EventBus與Otto性能對比Demo Apk](https://play.google.com/store/apps/details?id=de.greenrobot.eventperf)  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
  
#### 九、傳感器  
1. Great Android Sensing Toolkit  
Android感應器工具包，包含示例及使用過程中可能需要的算法  
項目地址：https://github.com/gast-lib/gast-lib  
Demo地址：https://play.google.com/store/apps/details?id=root.gast.playground  
文檔介紹：https://github.com/gast-lib/gast-lib#documentation  

1. SensorManager  
Android傳感器管理  
項目地址：https://github.com/nlathia/SensorManager  
文檔介紹：https://docs.google.com/document/d/1TqThJULb-4e6TGb1gdkAaPCfyuXStjJpbnt7a0OZ9OE/edit  

1. GPSLogger  
記錄GPS信息  
項目地址：https://github.com/mendhak/gpslogger  
Demo地址：https://play.google.com/store/apps/details?id=com.mendhak.gpslogger  
文檔介紹：http://code.mendhak.com/gpslogger/  

1. Pedometer  
計步器，使用硬件計步感應器  
項目地址：https://github.com/j4velin/Pedometer  

1. leapcast  
ChromeCast模擬器的App  
項目地址：https://github.com/dz0ny/leapcast  

1. Arduino-Communicator  
與Arduino通信的App  
項目地址：https://github.com/jeppsson/Arduino-Communicator  

1. android-pedometer  
Android計步器  
項目地址：https://github.com/bagilevi/android-pedometer  
Demo地址：http://pedometer.googlecode.com/files/Pedometer-1.4.apk  

1. OwnTracks for Android  
自己的軌迹記錄  
項目地址：https://github.com/owntracks/android  

1. Shake Detector library for Android   
Android手機震動搖晃檢測庫，提供供UI線程調用的回調接口  
項目地址：https://github.com/tbouron/ShakeDetector  
Demo地址：https://play.google.com/store/apps/details?id=com.github.tbouron.shakedetector.example  

1. Android heart rate monitor   
Android心跳檢測  
項目地址：https://github.com/phishman3579/android-heart-rate-monitor  

1. Bluetooth LE Library for Android   
藍牙源信息，包括寶庫Mac、更新時間、RSSI、UUID、信號源距離、影響範圍等信息  
項目地址：https://github.com/alt236/Bluetooth-LE-Library---Android  
Demo地址：https://play.google.com/store/apps/details?id=uk.co.alt236.btlescan  

1. farebot   
通過NFC 從公交卡中讀取數據的一個應用   
項目地址：https://github.com/codebutler/farebot     
    
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十、安全  
1. SQLCipher  
Sqlite加密工具  
項目地址：https://github.com/sqlcipher/sqlcipher  
幫助文檔：http://sqlcipher.net/sqlcipher-for-android/  

1. Conceal  
快速高效的進行文件加密解密  
項目地址：https://github.com/facebook/conceal  
文檔介紹：https://github.com/facebook/conceal#usage  

1. Android-PasscodeLock  
應用鎖，每次啓動或從任何Activity啓動應用都需要輸入四位數字的密碼方可進入  
項目地址：https://github.com/wordpress-mobile/Android-PasscodeLock  
Demo地址：https://play.google.com/store/apps/details?id=com.sothree.umano  
APP示例：Wordpress Android，支付寶，挖財  

1. GlowPadBackport  
將Android4.2的鎖屏界面解鎖擴展到Android1.6及1.6+  
項目地址：https://github.com/rock3r/GlowPadBackport  
Demo地址：https://play.google.com/store/apps/details?id=net.sebastianopoggi.samples.ui.GlowPadSample  
效果圖：![Renderings](https://lh6.ggpht.com/U070b6Lh6cVsVwx4jN-5nq0xqiB1PBzrYABPeJIEe2hZQ5UWOxc-FDUG77wADelToHA=h310-rw)  

1. GlowPadView  
Android 4鎖屏界面解鎖  
項目地址：https://github.com/nadavfima/GlowPadView  
效果圖：https://raw.github.com/nadavfima/GlowPadView/master/example.png  
   
1. android-lockpattern  
Android的圖案密碼解鎖  
項目地址：https://code.google.com/p/android-lockpattern/  
Demo地址：https://play.google.com/store/apps/details?id=group.pals.android.lib.ui.lockpattern.demo  
使用介紹：https://code.google.com/p/android-lockpattern/wiki/QuickUse  
示例APP：Android開機的圖案密碼解鎖，支付寶的密碼解鎖  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十一、插件化  
1. Android Plugin Framework  
Android插件式開發  
項目地址：https://github.com/umeng/apf  

1. xCombine  
Android App插件式插件開發  
項目地址：https://github.com/wyouflf/xCombine  
文檔介紹：http://my.oschina.net/u/1171837/blog/155377  

1. dynamic-load-apk  
Android動態加載Apk，熱部署  
項目地址：https://github.com/singwhatiwanna/dynamic-load-apk  
文檔介紹：http://blog.csdn.net/singwhatiwanna/article/details/22597587  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 十二、文件  
對不同文檔類型的處理，包括PDF、Word、EPub、Html、Zip等

1. purePDF  
允許從任何運行的SWF文件讀取和創建PDF文檔  
項目地址：https://github.com/sephiroth74/purePDF  
  
1. Office 365 SDK for Android Preview  
可支持Microsoft SharePoint Lists, Microsoft SharePoint Files, Microsoft Exchange Calendar, Microsoft Exchange Contacts, Microsoft Exchange Mail  
項目地址：https://github.com/OfficeDev/Office-365-SDK-for-Android  

1. OpenSpritz-Android  
EPub閱讀器  
項目地址：https://github.com/OnlyInAmerica/OpenSpritz-Android  
  
1. jsoup  
一個解析html的java庫，可方便的提取和操作數據  
項目地址：https://github.com/jhy/jsoup  
官方網站：http://jsoup.org/  
作用：(1) 從一個url、文件或string獲得html並解析  
(2) 利用dom遍曆或css選擇器查找、提取數據  
(3) 操作html元素  
(4) 根據白名單去除用于提交的非法數據防止xss攻擊  
(5) 輸出整齊的html  
   
1. ZIP  
java壓縮和解壓庫  
項目地址：https://github.com/zeroturnaround/zt-zip  
文檔介紹：https://github.com/zeroturnaround/zt-zip#examples  
作用：(1) 解壓和壓縮，並支持文件夾內遞歸操作  
(2) 支持包含和排除某些元素  
(3) 支持重命名元素  
(4) 支持遍曆zip包內容  
(5) 比較兩個zip包等功能  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. Image File Selector  
輕量級的圖片文件選擇器，用系統api選取，壓縮和裁切圖片，可以方便的得要指定尺寸的圖片  
項目地址：https://github.com/sw926/ImageFileSelector  

#### 十三、其他  
1. Salvage view  
帶View緩存的Viewpager PagerAdapter，很方便使用  
項目地址：https://github.com/JakeWharton/salvage  
   
1. Android Priority Job Queue  
Android後台任務隊列  
項目地址：https://github.com/path/android-priority-jobqueue  
文檔介紹：https://github.com/path/android-priority-jobqueue#getting-started  
   
1. Cobub Razor  
開源的mobile行爲分析系統，包括web端、android端，支持ios和window phone  
項目地址：https://github.com/cobub/razor  
Demo地址：http://demo.cobub.com/razor  
網站介紹：http://dev.cobub.com/  
   
1. aFileChooser  
文件選擇器，可內嵌到程序中，而無需使用系統或三方文件選擇器。  
項目地址：https://github.com/iPaulPro/aFileChooser  
   
1. androidpn  
基于xmpp協議的消息推送解決方案，包括服務器端和android端。  
項目地址：https://github.com/dannytiehui/androidpn  

1. Bolts  
Android的異步編程模式  
項目地址：https://github.com/BoltsFramework/Bolts-Android/  
與AsyncTask比較：(1) 使用的是無大小限制的線程池  
(2) 任務可組合可級聯，防止了代碼耦合  

1. CastCompanionLibrary-android  
使Android程序中更快的接入Google Cast  
項目地址：https://github.com/googlecast/CastCompanionLibrary-android  
文檔介紹：https://developers.google.com/cast/  
  
1. CastVideos-android  
從Android設備分享Video通過Google Cast  
項目地址：https://github.com/googlecast/CastVideos-android  
文檔介紹：https://developers.google.com/cast/  
  
1. Uninstall_Statics  
Android應用自身被卸載監聽及打開浏覽器等反饋功能實現  
項目地址：https://github.com/sevenler/Uninstall_Statics  
文檔介紹：http://www.cnblogs.com/zealotrouge/p/3157126.html  
http://www.cnblogs.com/zealotrouge/p/3159772.html  

1. Memento  
保證在系統配置改變時，Activity中的某些數據可以簡單安全的保持不變  
項目地址：https://github.com/mttkay/memento  
文檔介紹：https://github.com/mttkay/memento#usage  
   
1. FreeFlow  
布局引擎，更簡單的創建自定義布局，並且當數據和布局改變時更美觀的過渡動畫  
項目地址：https://github.com/Comcast/FreeFlow  
Demo地址：https://github.com/Comcast/FreeFlow/releases  

1. Android Gesture Detectors Framework  
Android手勢框架，支持雙指旋轉、移動、平移、縮放等  
項目地址：https://github.com/Almeros/android-gesture-detectors  

1. Mapbox Android SDK  
Android Map的替代版  
項目地址：https://github.com/mapbox/mapbox-android-sdk  

1. Activity animation  
Activity跳轉動畫，支持各個方向波浪的效果  
項目地址：https://github.com/flavienlaurent/activityanimation   
在線演示：https://www.youtube.com/watch?v=-E0sc6w_Jck  

1. KryoNet  
通過NIO提供客戶端和服務器端TCP/UDP網絡傳輸的Java庫  
項目地址：https://github.com/EsotericSoftware/kryonet  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

## 第三部分 優秀項目  
主要介紹那些Android還不錯的完整項目，目前包含的項目主要依據是項目有意思或項目分層規範比較好。  
Linux  
項目地址：https://github.com/torvalds/linux  
Android  
項目地址：https://android.googlesource.com/ 或 https://github.com/android  
以上兩個項目，不解釋  
   
(1) ZXing  
二維碼掃描工具  
項目地址：https://github.com/zxing/zxing 或 https://code.google.com/p/zxing/  
APK地址：https://play.google.com/store/apps/details?id=com.google.zxing.client.android  
PS：現在市面上很多應用的二維碼掃描功能都是從這個修改而來  
   
(2) photup  
編輯機批量上傳照片到facebook上  
項目地址：https://github.com/chrisbanes/photup  
APK地址：https://play.google.com/store/apps/details?id=uk.co.senab.photup  
PS：代碼分包合理，很棒。不過這個項目依賴的開源項目比較多，比較難編譯  
     
(3) github-android 
Github的Android客戶端項目  
項目地址：https://github.com/github/android  
APK地址：https://play.google.com/store/apps/details?id=com.github.mobile  
   
(4) Notes  
MIUI便簽  
項目地址：https://github.com/MiCode/Notes  
APK地址：https://github.com/Trinea/TrineaDownload/blob/master/miui-note-demo.apk?raw=true  
PS：項目分包比較合理，相比較miui的文件管理器https://github.com/MiCode/FileExplorer 代碼規範較好得多  
   
(5) weicuiyuan  
四次元-新浪微博客戶端  
項目地址：https://github.com/qii/weiciyuan  
APK地址：https://play.google.com/store/apps/details?id=org.qii.weiciyuan  
   
(6) gnucash-android  
一個記賬理財軟件  
項目地址：https://github.com/codinguser/gnucash-android  
APK地址：http://play.google.com/store/apps/details?id=org.gnucash.android  
   
(7) AntennaPod  
支持rss訂閱、音樂訂閱  
項目地址：https://github.com/danieloeh/AntennaPod  
APK地址：https://play.google.com/store/apps/details?id=de.danoeh.antennapod  
   
(8) ChaseWhisplyProject  
打鬼遊戲  
項目地址：https://github.com/tvbarthel/ChaseWhisplyProject  
APK地址：https://play.google.com/store/apps/details?id=fr.tvbarthel.games.chasewhisply  
   
(9) Tweet Lanes  
功能完整的Twitter客戶端  
項目地址：https://github.com/chrislacy/TweetLanes  
APK地址：https://play.google.com/store/apps/details?id=com.tweetlanes.android  

(10) Financius  
簡單易用的記賬程序  
項目地址：https://github.com/mvarnagiris/Financius  
APK地址：https://play.google.com/store/apps/details?id=com.code44.finance  

(11) todo.txt-android  
todo.txt的官方Android應用  
項目地址：https://github.com/ginatrapani/todo.txt-android  
APK地址：https://play.google.com/store/apps/details?id=com.todotxt.todotxttouch  

(12) simpletask  
基于todo.txt官方應用的另一個客戶端  
項目地址：https://github.com/mpcjanssen/simpletask-android  
APK地址：https://play.google.com/store/apps/details?id=nl.mpcjanssen.todotxtholo  

(13) Muzei Live Wallpaper  
定時更換桌面精美壁紙  
項目地址：https://github.com/romannurik/muzei  
APK地址：https://play.google.com/store/apps/details?id=net.nurik.roman.muzei  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

## 第四部分 開發工具及測試工具  
主要介紹和Android開發工具和測試工具相關的開源項目。  <a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
#### 一、開發效率工具  
1. Json2Java  
根據JSon數據自動生成對應的Java實體類，還支持Parcel、Gson Annotations對應代碼自動生成。期待後續的提取父類以及多url構建整個工程的功能  
項目地址：https://github.com/jonfhancock/JsonToJava  
在線演示：http://jsontojava.appspot.com/  

1. IntelliJ Plugin for Android Parcelable boilerplate code generation  
Android studio插件，生成Parcelable代碼  
項目地址：https://github.com/mcharmas/android-parcelable-intellij-plugin  
效果圖：![Holo Colors Idea](https://github.com/mcharmas/android-parcelable-intellij-plugin/raw/master/screenshot.png)  
  
1. Android Holo Colors IntelliJ Plugin  
Android studio插件，生成holo樣式9 patch圖片  
項目地址：https://github.com/jeromevdl/android-holo-colors-idea-plugin  
效果圖：![Holo Colors Idea](https://raw.github.com/jeromevdl/android-holo-colors-idea-plugin/master/other/holocolorsidea.png)  

1. Android Drawable Factory  
用于生成各個分辨率的圖片  
項目地址：https://github.com/tizionario/AndroidDrawableFactory  
效果圖：![Android Drawable Factory](https://github-camo.global.ssl.fastly.net/5c3844b345a9779296f996490070dab0bfc9dbf5/68747470733a2f2f646c2e64726f70626f7875736572636f6e74656e742e636f6d2f752f32363636343637352f416e64726f69644472617761626c65466163746f72792f312e706e67)  

1. SelectorChapek for Android  
Android Studio插件，可根據固定文件名格式資源自動生成drawable selectors xml文件。  
項目地址：https://github.com/inmite/android-selector-chapek  
   
1. Android Action Bar Style Generator  
Android ActionBar樣式生成器，可在線選擇ActionBar樣式自動生成所需要的圖片資源及xml文件  
項目地址：https://github.com/jgilfelt/android-actionbarstylegenerator  
在線演示：http://jgilfelt.github.io/android-actionbarstylegenerator/  

1. ButterKnifeZelezny  
用于快速生成[ButterKnife](https://github.com/JakeWharton/butterknife)View注入代碼的Android Studio/IDEA插件  
項目地址：https://github.com/inmite/android-butterknife-zelezny  

1. RoboCoP  
利用Gradle task根據固定格式的json文件生成ContentProvider  
項目地址：https://github.com/mediarain/RoboCoP  

1. appiconsizes  
用于生成各個分辨率的圖片  
項目地址：http://www.appiconsizes.com/  

1. Gradle Retrolambda Plugin  
[Retrolambda](https://github.com/orfjackal/retrolambda)是將Java8的Lambdas應用于Java7的工具，本項目是Gradle插件，通過Retrolambda從而使Java或Android項目用Java8的Lambdas編寫，將編譯後的字節碼轉換爲Java6和7的字節碼從而正常運行  
項目地址：https://github.com/evant/gradle-retrolambda  

1. Dagger IntelliJ Plugin  
dagger的intellij插件  
項目地址：https://github.com/square/dagger-intellij-plugin  

1. Android Gen Drawable Maven plugin  
在編譯時根據SVG描述文件生成不同分辨率的jpg、png或點9圖片  
項目地址：https://github.com/avianey/androidgendrawable-maven-plugin  

1. jsonschema2pojo  
根據Json內容生成java對象，支持jackjson和gson。  
項目地址：https://github.com/joelittlejohn/jsonschema2pojo  
在線演示：http://www.jsonschema2pojo.org/   
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 二、開發自測相關  
1. Quality Tools for Android  
Android測試及自測工具集合和示例  
項目地址：https://github.com/stephanenicolas/Quality-Tools-for-Android  

1. android-test-kit  
Google的Android測試工具  
包括GoogleInstrumentationTestRunner(增強版的InstrumentationTestRunner)和Espresso(用于快速寫出可靠測試用例的API)  
項目地址：https://code.google.com/p/android-test-kit/  
文檔介紹：https://code.google.com/p/android-test-kit/w/list  
  
1. robolectric  
測試用例編寫框架  
項目地址：https://github.com/robolectric/robolectric  
Demo地址：https://github.com/robolectric/robolectricsample  
文檔介紹：http://robolectric.org/  
特點：(1). 不需要模擬器在一般JVM就可以運行測試用例  
(2). 能完成在真機上的大部分測試包括感應器  
其他的測試用例及相關模塊Mock可見：[android-mock](https://code.google.com/p/android-mock/), [mockito](https://code.google.com/p/mockito/), [easy-mock](https://github.com/easymock/easymock)  

1. Android FEST  
提供一些列方便的斷言，可用于提高編寫Android自測代碼效率  
項目地址：https://github.com/square/fest-android  

1. BoundBox  
可用于測試類各種訪問權限的屬性、方法。實際是通過BoundBox這個annotation生成一個屬性和方法都是public權限的中間類並對此類進行測試完成的  
項目地址：https://github.com/stephanenicolas/boundbox  

1. Hugo  
用于打印函數信息及執行時間的工具，僅在debug模式生效  
項目地址：https://github.com/JakeWharton/hugo  
  
1. scalpel  
在應用下面添加一層用于界面調試，待詳細補充 // TODO   
項目地址：https://github.com/JakeWharton/scalpel  
  
1. Android Screenshot library  
Android截圖工具類，用于在持續集成時截圖   
項目地址：https://github.com/rtyley/android-screenshot-lib  
  
1. sonar-android-lint-plugin  
將android lint的錯誤在sonar中展現   
項目地址：https://github.com/SonarCommunity/sonar-android  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 三、測試工具  
1. Spoon  
可用于android不同機型設備自動化測試，能將應用apk和測試apk運行在不同機器上並生成相應測試報告。  
項目地址：https://github.com/square/spoon    

1. Tencent APT  
APT是騰訊開源的一個Android平台高效性能測試組件，提供豐富實用的功能，適用于開發自測、定位性能瓶頸；測試人員完成性能基准測試、競品對比測試  
項目地址：https://github.com/stormzhang/APT  

1. Emmagee  
網易開源的性能測試工具，包括CPU、內存、網絡流量、啓動時間、電池狀態等  
項目地址：https://github.com/NetEase/Emmagee  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 四、開發及編譯環境  
1. Buck  
facebook開源的Android編譯工具，效率是ant的兩倍。主要優點在于：  
(1) 加快編譯速度，通過並行利用多核cpu和跟蹤不變資源減少增量編譯時間實現  
(2) 可以在編譯系統中生成編譯規則而無須另外的系統生成編譯規則文件  
(3) 編譯同時可生成單元測試結果  
(4) 既可用于IDE編譯也可用于持續集成編譯  
(5) facebook持續優化中  
項目地址：https://github.com/facebook/buck  
   
1. Android Maven Plugin  
Android Maven插件，可用于對android三方依賴進行管理。在J2EE開發中，maven是非常成熟的依賴庫管理工具，可統一管理依賴庫。  
項目地址：https://github.com/jayway/maven-android-plugin  

1. umeng-muti-channel-build-tool  
渠道打包工具  
項目地址：https://github.com/umeng/umeng-muti-channel-build-tool  
另可參見Google的構建系統Gradle：http://tools.android.com/tech-docs/new-build-system/user-guide  
   
1. Genymotion  
目前最好用最快的android模擬器  
項目地址：http://www.genymotion.com/  
Android studio集成控件： http://plugins.jetbrains.com/plugin/7269?pr=idea  
Cyril Mottier推薦：http://cyrilmottier.com/2013/06/27/a-productive-android-development-environment/  
  
1. gradle-mvn-push  
方便的將Gradle的Artifacts上傳到Maven倉庫  
項目地址：https://github.com/chrisbanes/gradle-mvn-push  
文檔介紹：https://github.com/chrisbanes/gradle-mvn-push#usage    

1. Android Emulator Plugin for Jenkins  
Android模擬器 jenkins插件，用于Jenkins做持續集成時跑模擬器測試  
項目地址：https://github.com/jenkinsci/android-emulator-plugin  

1. Android Maven Plugin  
管理應用所需要的依賴庫。包括的構建工具有Maven、Gradle、ant、sbt  
項目地址：https://github.com/mosabua/maven-android-sdk-deployer  

1. SDK Manager Plugin  
下載和管理Android SDK的Gradle插件  
項目地址：https://github.com/JakeWharton/sdk-manager-plugin  

1. Gradle Protobuf Plugin  
將.proto文件轉換成Java文件的gradle插件  
項目地址：https://github.com/andrewkroh/gradle-protobuf-plugin  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 五、其他  
1. ViewServer  
允許app運行在任何手機上都可以用HierarchyViewer查看  
項目地址：https://github.com/romainguy/ViewServer  
   
1. GridWichterle for Android  
在整個系統上顯示一個grid，用來幫助查看應用布局及使得布局更美觀，可設置grid網格大小和顔色，android推薦48dp和8dp，可見 Android Design Guidelines – Metrics and Grids  
項目地址：https://github.com/inmite/android-grid-wichterle  
APK地址：https://play.google.com/store/apps/details?id=eu.inmite.android.gridwichterle  
PS：比起hierarchyviewer相差甚遠，不過偶爾可用來作爲布局查看工具。  

1. Catlog  
手機端log查看工具，支持不同顔色顯示、關鍵字過濾、級別過濾、進程id過濾、錄制功能等  
項目地址：https://github.com/nolanlawson/Catlog  
在線演示：https://play.google.com/store/apps/details?id=com.nolanlawson.logcat  
   
1. PID Cat  
根據package查看logcat日志  
項目地址：https://github.com/JakeWharton/pidcat  

1. ACRA  
應用崩潰信息上報到GoogleDoc工具，網頁版展現結果三方開源地址https://github.com/BenoitDuffez/crashreportsviewer  
項目地址：https://github.com/ACRA/acra  
文檔地址：https://github.com/ACRA/acra/wiki/BasicSetup  

1. Crashlytics  
提供豐富的應用崩潰信息收集  
輕量級，豐富，可自定義應用崩潰信息收集器，附有郵件通知  
項目地址：http://www.crashlytics.com/  
集成插件：[Android Studio, Eclipse and IntelliJ](http://try.crashlytics.com/sdk-android/?utm_source=blog&utm_medium=blog&utm_campaign=Announcing_android_studio_wp&utm_content=CTA_button)  

1. Android Resource Navigator  
chrome插件，可以方便的查看github上android源碼工程的styles.xml和themes.xml。主要功能：  
(1) 快速打開android styles.xml themes.xml  
(2) 方便在資源間跳轉。styles.xml themes.xml文件中資源鏈接跳轉，可以方便跳轉到某個資源  
(3) 方便查找某個style和theme。chrome地址欄輸入arn+tab+搜索內容回車即可  
(4) 自動下載不同分辨率下的drawable  
(5) 通過映射查找那些不是按照固定命名規則命名的style和theme  
項目地址：https://github.com/jgilfelt/android-resource-navigator  
示例：https://chrome.google.com/webstore/detail/android-resource-navigato/agoomkionjjbejegcejiefodgbckeebo?hl=en&gl=GB  

1. android-resource-remover  
根據lint的提示刪除項目中無用的資源，減少包的大小  
項目地址：https://github.com/KeepSafe/android-resource-remover  

1. Telescope  
通過手勢截圖以特定主題發送到特定郵箱地址報告Bug  
項目地址：https://github.com/mattprecious/telescope  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
  
## 第五部分  
主要介紹那些樂于分享並且有一些很不錯的開源項目的個人和組織。Follow大神，深挖大神的項目和following，你會發現很多。  

#### 一、個人  
1. JakeWharton  
就職于Square，絕對牛逼的大神，項目主要集中在Android版本兼容，ViewPager及開發工具上  
Github地址：https://github.com/JakeWharton  
代表作：ActionBarSherlock，Android-ViewPagerIndicator，Nine Old Androids，SwipeToDismissNOA，hugo，butterknife，Android-DirectionalViewPager, scalpel    
pidcat另外對square及其他開源項目有很多貢獻  
主頁：http://jakewharton.com/  
   
1. Chris Banes  
Github地址：https://github.com/chrisbanes  
代表作：ActionBar-PullToRefresh，PhotoView，Android-BitmapCache，Android-PullToRefresh  
主頁：http://chris.banes.me/  
   
1. Koushik Dutta  
就職于ClockworkMod  
Github地址：https://github.com/koush  
代表作：Superuser，AndroidAsync，UrlImageViewHelper，ion, 另外對https://github.com/CyanogenMod 的開源項目有很多貢獻  
主頁：http://koush.com/  
   
1. Simon Vig  
Github地址：https://github.com/SimonVT  
代表作：android-menudrawer，MessageBar  
主頁：http://simonvt.net/  
   
1. Manuel Peinado  
Github地址：https://github.com/ManuelPeinado  
代表作：FadingActionBar，GlassActionBar，RefreshActionItem，QuickReturnHeader  
   
1. Emil Sj?lander  
Github地址：https://github.com/emilsjolander  
代表作：StickyListHeaders，sprinkles，android-FlipView  
主頁：http://emilsjolander.se/  
   
1. greenrobot  
Github地址：https://github.com/greenrobot  
代表作：greenDAO，EventBus  
主頁：http://greenrobot.de/  
   
1. Jeff Gilfelt  
Github地址：https://github.com/jgilfelt  
代表作：android-mapviewballoons，android-viewbadger，android-actionbarstylegenerator，android-sqlite-asset-helper  
主頁：http://jeffgilfelt.com  

1.  Romain Guy  
Android team成員(2013.10已離開Android team，仍在Google)  
Github地址：https://github.com/romainguy  
代表作：ViewServer  
主頁：http://www.curious-creature.org/category/android/   
個人攝影作品：http://www.flickr.com/photos/romainguy  

1. sephiroth74  
就職于Aviary.com  
Github地址：https://github.com/sephiroth74  
代表作：ImageViewZoom，HorizontalVariableListView，AndroidWheel，purePDF  
主頁：http://www.sephiroth.it/   

1. Cyril Mottier    
Google開發者專家認證，發布一些Android技巧及文章  
Github地址：https://github.com/cyrilmottier  
代表作：GreenDroid，Polaris  
主頁：http://cyrilmottier.com/  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 二、組織  
1. Square  
有態度有良心的企業，很多不錯的分享  
Github地址：https://github.com/square   
代表作：okhttp、fest-android，android-times-square、picasso、dagger、spoon等等    
主頁：http://square.github.io/  
   
1. Inmite s.r.o.  
Github地址：https://github.com/inmite  
代表作：android-styled-dialogs，android-grid-wichterle，android-selector-chapek  
主頁：http://www.inmite.eu/  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 三、博客  
1. Chet Haase  
Android framework UI team 成員  
主頁：http://graphics-geek.blogspot.com/  
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" title="返回目錄" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

## License

    Copyright 2014 trinea.cn

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

